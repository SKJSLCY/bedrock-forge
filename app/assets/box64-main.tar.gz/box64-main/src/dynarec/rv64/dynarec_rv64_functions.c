// SPDX-License-Identifier: MIT
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

#include "debug.h"
#include "box64context.h"
#include "box64cpu.h"
#include "emu/x64emu_private.h"
#include "x64emu.h"
#include "box64stack.h"
#include "callback.h"
#include "emu/x64run_private.h"
#include "emu/x87emu_private.h"
#include "rv64_emitter.h"
#include "x64trace.h"
#include "signals.h"
#include "dynarec_native.h"
#include "dynarec_rv64_private.h"
#include "dynarec_rv64_functions.h"
#include "custommem.h"
#include "bridge.h"
#include "rv64_lock.h"
#include "gdbjit.h"
#include "perfmap.h"

static int fpu_scratch_vreg(int n)
{
    if (n < 7)
        return SCRATCH0 + n;
    abort();
}

// Get a FPU scratch reg
int fpu_get_scratch(dynarec_rv64_t* dyn)
{
    return fpu_scratch_vreg(dyn->e.fpu_scratch++); // return an Sx
}

// Get a FPU scratch reg aligned to LMUL
int fpu_get_scratch_lmul(dynarec_rv64_t* dyn, int lmul)
{
    if (cpuext.xtheadvector) {
        int reg = SCRATCH0 + dyn->e.fpu_scratch;
        int skip = (reg % (1 << lmul)) ? (1 << lmul) - (reg % (1 << lmul)) : 0;
        dyn->e.fpu_scratch += skip + 1;
        return reg + skip;
    }
    int n = dyn->e.fpu_scratch;
    int reg = fpu_scratch_vreg(n);
    int skip = (reg % (1 << lmul)) ? (1 << lmul) - (reg % (1 << lmul)) : 0;
    dyn->e.fpu_scratch += skip + (1 << lmul);
    return fpu_scratch_vreg(n + skip);
}

// Reset scratch regs counter
void fpu_reset_scratch(dynarec_rv64_t* dyn)
{
    dyn->e.fpu_scratch = 0;
    dyn->pending_zero_flushed = 0;
}
// Get a x87 double reg
int fpu_get_reg_x87(dynarec_rv64_t* dyn, int t, int n)
{
    int i = X870;
    while (dyn->e.fpuused[i])
        ++i;
    dyn->e.fpuused[i] = 1;
    dyn->e.extcache[i].n = n;
    dyn->e.extcache[i].t = t;
    dyn->e.extcache[i].y = 0;
    dyn->e.news |= (1 << i);
    return EXTREG(i); // return a Dx
}
// Free a FPU reg
void fpu_free_reg(dynarec_rv64_t* dyn, int reg)
{
    int idx = EXTIDX(reg);
    // TODO: check upper limit?
    dyn->e.fpuused[idx] = 0;
    if (dyn->e.extcache[idx].t != EXT_CACHE_ST_F && dyn->e.extcache[idx].t != EXT_CACHE_ST_D && dyn->e.extcache[idx].t != EXT_CACHE_ST_I64)
        dyn->e.extcache[idx].v = 0;
}

// Get an MMX reg
int fpu_get_reg_emm(dynarec_rv64_t* dyn, int t, int emm)
{
    int i = EMM0 + emm;
    dyn->e.fpuused[i] = 1;
    dyn->e.extcache[i].t = t;
    dyn->e.extcache[i].n = emm;
    dyn->e.extcache[i].y = 0;
    dyn->e.news |= (1 << (i));
    return EXTREG(i);
}

// Get an XMM reg
int fpu_get_reg_xmm(dynarec_rv64_t* dyn, int t, int xmm)
{
    int i = XMM0 + xmm;
    dyn->e.fpuused[i] = 1;
    dyn->e.extcache[i].t = t;
    dyn->e.extcache[i].n = xmm;
    dyn->e.extcache[i].y = 0;
    dyn->e.news |= (1 << i);
    return EXTREG(i);
}
// Reset fpu regs counter
static void fpu_reset_reg_extcache(dynarec_rv64_t* dyn, extcache_t* e)
{
    for (int i = 0; i < 32; ++i) {
        e->fpuused[i] = 0;
        e->extcache[i].v = 0;
    }
    dyn->vector_sew = VECTOR_SEWNA;
    dyn->vtype_restore = VECTOR_SEWNA;
}
void fpu_reset_reg(dynarec_rv64_t* dyn)
{
    fpu_reset_reg_extcache(dyn, &dyn->e);
}

int extcache_no_i64(dynarec_rv64_t* dyn, int ninst, int st, int a)
{
    if (a == EXT_CACHE_ST_I64) {
        extcache_promote_double(dyn, ninst, st);
        return EXT_CACHE_ST_D;
    }
    return a;
}

int extcache_get_st(dynarec_rv64_t* dyn, int ninst, int a)
{
    if (dyn->insts[ninst].e.swapped) {
        if (dyn->insts[ninst].e.combined1 == a)
            a = dyn->insts[ninst].e.combined2;
        else if (dyn->insts[ninst].e.combined2 == a)
            a = dyn->insts[ninst].e.combined1;
    }
    for (int i = 0; i < 24; ++i)
        if ((dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F
                || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_D
                || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_I64)
            && dyn->insts[ninst].e.extcache[i].n == a)
            return dyn->insts[ninst].e.extcache[i].t;
    // not in the cache yet, so will be fetched...
    return EXT_CACHE_ST_D;
}

int extcache_get_current_st(dynarec_rv64_t* dyn, int ninst, int a)
{
    (void)ninst;
    if (!dyn->insts)
        return EXT_CACHE_ST_D;
    for (int i = 0; i < 24; ++i)
        if ((dyn->e.extcache[i].t == EXT_CACHE_ST_F
                || dyn->e.extcache[i].t == EXT_CACHE_ST_D
                || dyn->e.extcache[i].t == EXT_CACHE_ST_I64)
            && dyn->e.extcache[i].n == a)
            return dyn->e.extcache[i].t;
    // not in the cache yet, so will be fetched...
    return EXT_CACHE_ST_D;
}

int extcache_get_st_f(dynarec_rv64_t* dyn, int ninst, int a)
{
    for (int i = 0; i < 24; ++i)
        if (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F
            && dyn->insts[ninst].e.extcache[i].n == a)
            return i;
    return -1;
}

int extcache_get_st_f_i64(dynarec_rv64_t* dyn, int ninst, int a)
{
    for (int i = 0; i < 24; ++i)
        if ((dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_I64 || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F)
            && dyn->insts[ninst].e.extcache[i].n == a)
            return i;
    return -1;
}

int extcache_get_st_f_noback(dynarec_rv64_t* dyn, int ninst, int a)
{
    for (int i = 0; i < 24; ++i)
        if (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F
            && dyn->insts[ninst].e.extcache[i].n == a)
            return i;
    return -1;
}

int extcache_get_st_f_i64_noback(dynarec_rv64_t* dyn, int ninst, int a)
{
    for (int i = 0; i < 24; ++i)
        if ((dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_I64 || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F)
            && dyn->insts[ninst].e.extcache[i].n == a)
            return i;
    return -1;
}

int extcache_get_current_st_f(dynarec_rv64_t* dyn, int a)
{
    for (int i = 0; i < 24; ++i)
        if (dyn->e.extcache[i].t == EXT_CACHE_ST_F
            && dyn->e.extcache[i].n == a)
            return i;
    return -1;
}

int extcache_get_current_st_f_i64(dynarec_rv64_t* dyn, int a)
{
    for (int i = 0; i < 24; ++i)
        if ((dyn->e.extcache[i].t == EXT_CACHE_ST_I64 || dyn->e.extcache[i].t == EXT_CACHE_ST_F)
            && dyn->e.extcache[i].n == a)
            return i;
    return -1;
}

static void extcache_promote_double_forward(dynarec_rv64_t* dyn, int ninst, int maxinst, int a);
static void extcache_promote_double_internal(dynarec_rv64_t* dyn, int ninst, int maxinst, int a);
static void extcache_promote_double_combined(dynarec_rv64_t* dyn, int ninst, int maxinst, int a)
{
    if (a == dyn->insts[ninst].e.combined1 || a == dyn->insts[ninst].e.combined2) {
        if (a == dyn->insts[ninst].e.combined1) {
            a = dyn->insts[ninst].e.combined2;
        } else
            a = dyn->insts[ninst].e.combined1;
        int i = extcache_get_st_f_i64_noback(dyn, ninst, a);
        // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_combined, ninst=%d combined%c %d i=%d (stack:%d/%d)\n", ninst, (a == dyn->insts[ninst].e.combined2)?'2':'1', a ,i, dyn->insts[ninst].e.stack_push, -dyn->insts[ninst].e.stack_pop);
        if (i >= 0) {
            dyn->insts[ninst].e.extcache[i].t = EXT_CACHE_ST_D;
            if (dyn->insts[ninst].x87precision) dyn->need_x87check = 2;
            if (!dyn->insts[ninst].e.barrier)
                extcache_promote_double_internal(dyn, ninst - 1, maxinst, a - dyn->insts[ninst].e.stack_push);
            // go forward is combined is not pop'd
            if (a - dyn->insts[ninst].e.stack_pop >= 0)
                if (!dyn->insts[ninst + 1].e.barrier)
                    extcache_promote_double_forward(dyn, ninst + 1, maxinst, a - dyn->insts[ninst].e.stack_pop);
        }
    }
}
static void extcache_promote_double_internal(dynarec_rv64_t* dyn, int ninst, int maxinst, int a)
{
    if (dyn->insts[ninst + 1].e.barrier)
        return;
    while (ninst >= 0) {
        a += dyn->insts[ninst].e.stack_pop; // adjust Stack depth: add pop'd ST (going backward)
        int i = extcache_get_st_f_i64(dyn, ninst, a);
        // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_internal, ninst=%d, a=%d st=%d:%d, i=%d\n", ninst, a, dyn->insts[ninst].e.stack, dyn->insts[ninst].e.stack_next, i);
        if (i < 0) return;
        dyn->insts[ninst].e.extcache[i].t = EXT_CACHE_ST_D;
        if (dyn->insts[ninst].x87precision) dyn->need_x87check = 2;
        // check combined propagation too
        if (dyn->insts[ninst].e.combined1 || dyn->insts[ninst].e.combined2) {
            if (dyn->insts[ninst].e.swapped) {
                // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_internal, ninst=%d swapped %d/%d vs %d with st %d\n", ninst, dyn->insts[ninst].e.combined1 ,dyn->insts[ninst].e.combined2, a, dyn->insts[ninst].e.stack);
                if (a == dyn->insts[ninst].e.combined1)
                    a = dyn->insts[ninst].e.combined2;
                else if (a == dyn->insts[ninst].e.combined2)
                    a = dyn->insts[ninst].e.combined1;
            } else {
                // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_internal, ninst=%d combined %d/%d vs %d with st %d\n", ninst, dyn->insts[ninst].e.combined1 ,dyn->insts[ninst].e.combined2, a, dyn->insts[ninst].e.stack);
                extcache_promote_double_combined(dyn, ninst, maxinst, a);
            }
        }
        a -= dyn->insts[ninst].e.stack_push; // // adjust Stack depth: remove push'd ST (going backward)
        --ninst;
        if (ninst < 0 || a < 0 || dyn->insts[ninst].e.barrier)
            return;
    }
}

static void extcache_promote_double_forward(dynarec_rv64_t* dyn, int ninst, int maxinst, int a)
{
    while ((ninst != -1) && (ninst < maxinst) && (a >= 0)) {
        a += dyn->insts[ninst].e.stack_push; // // adjust Stack depth: add push'd ST (going forward)
        if ((dyn->insts[ninst].e.combined1 || dyn->insts[ninst].e.combined2) && dyn->insts[ninst].e.swapped) {
            // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_forward, ninst=%d swapped %d/%d vs %d with st %d\n", ninst, dyn->insts[ninst].e.combined1 ,dyn->insts[ninst].e.combined2, a, dyn->insts[ninst].e.stack);
            if (a == dyn->insts[ninst].e.combined1)
                a = dyn->insts[ninst].e.combined2;
            else if (a == dyn->insts[ninst].e.combined2)
                a = dyn->insts[ninst].e.combined1;
        }
        int i = extcache_get_st_f_i64_noback(dyn, ninst, a);
        // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_forward, ninst=%d, a=%d st=%d:%d(%d/%d), i=%d\n", ninst, a, dyn->insts[ninst].e.stack, dyn->insts[ninst].e.stack_next, dyn->insts[ninst].e.stack_push, -dyn->insts[ninst].e.stack_pop, i);
        if (i < 0) return;
        dyn->insts[ninst].e.extcache[i].t = EXT_CACHE_ST_D;
        if (dyn->insts[ninst].x87precision) dyn->need_x87check = 2;
        // check combined propagation too
        if ((dyn->insts[ninst].e.combined1 || dyn->insts[ninst].e.combined2) && !dyn->insts[ninst].e.swapped) {
            // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double_forward, ninst=%d combined %d/%d vs %d with st %d\n", ninst, dyn->insts[ninst].e.combined1 ,dyn->insts[ninst].e.combined2, a, dyn->insts[ninst].e.stack);
            extcache_promote_double_combined(dyn, ninst, maxinst, a);
        }
        a -= dyn->insts[ninst].e.stack_pop; // adjust Stack depth: remove pop'd ST (going forward)
        if (dyn->insts[ninst].x64.has_next && !dyn->insts[ninst].e.barrier)
            ++ninst;
        else
            ninst = -1;
    }
    if (ninst == maxinst)
        extcache_promote_double(dyn, ninst, a);
}

void extcache_promote_double(dynarec_rv64_t* dyn, int ninst, int a)
{
    int i = extcache_get_current_st_f_i64(dyn, a);
    // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double, ninst=%d a=%d st=%d i=%d\n", ninst, a, dyn->e.stack, i);
    if (i < 0) return;
    dyn->e.extcache[i].t = EXT_CACHE_ST_D;
    dyn->insts[ninst].e.extcache[i].t = EXT_CACHE_ST_D;
    if (dyn->insts[ninst].x87precision) dyn->need_x87check = 2;
    // check combined propagation too
    if (dyn->e.combined1 || dyn->e.combined2) {
        if (dyn->e.swapped) {
            // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double, ninst=%d swapped! %d/%d vs %d\n", ninst, dyn->e.combined1 ,dyn->e.combined2, a);
            if (dyn->e.combined1 == a)
                a = dyn->e.combined2;
            else if (dyn->e.combined2 == a)
                a = dyn->e.combined1;
        } else {
            // if(dyn->need_dump) dynarec_log(LOG_NONE, "extcache_promote_double, ninst=%d combined! %d/%d vs %d\n", ninst, dyn->e.combined1 ,dyn->e.combined2, a);
            if (dyn->e.combined1 == a)
                extcache_promote_double(dyn, ninst, dyn->e.combined2);
            else if (dyn->e.combined2 == a)
                extcache_promote_double(dyn, ninst, dyn->e.combined1);
        }
    }
    a -= dyn->insts[ninst].e.stack_push; // // adjust Stack depth: remove push'd ST (going backward)
    if (!ninst || a < 0) return;
    extcache_promote_double_internal(dyn, ninst - 1, ninst, a);
}

int extcache_combine_st(dynarec_rv64_t* dyn, int ninst, int a, int b)
{
    dyn->e.combined1 = a;
    dyn->e.combined2 = b;
    if (extcache_get_current_st(dyn, ninst, a) == EXT_CACHE_ST_F
        && extcache_get_current_st(dyn, ninst, b) == EXT_CACHE_ST_F)
        return EXT_CACHE_ST_F;
    return EXT_CACHE_ST_D;
}

static int isCacheEmpty(dynarec_native_t* dyn, int ninst)
{
    if (dyn->insts[ninst].e.stack_next) {
        return 0;
    }
    for (int i = 0; i < 24; ++i)
        if (dyn->insts[ninst].e.extcache[i].v) { // there is something at ninst for i
            if (!(
                    (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F
                        || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_D
                        || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_I64)
                    && dyn->insts[ninst].e.extcache[i].n < dyn->insts[ninst].e.stack_pop))
                return 0;
        }
    return 1;
}

int fpuCacheNeedsTransform(dynarec_rv64_t* dyn, int ninst)
{
    int i2 = dyn->insts[ninst].x64.jmp_insts;
    if (i2 < 0)
        return 1;
    if ((dyn->insts[i2].x64.barrier & BARRIER_FLOAT))
        // if the barrier as already been apply, no transform needed
        return ((dyn->insts[ninst].x64.barrier & BARRIER_FLOAT)) ? 0 : (isCacheEmpty(dyn, ninst) ? 0 : 1);
    int ret = 0;
    if (!i2) { // restore the state the first instruction was emitted with
        if (dyn->insts[ninst].e.stack_next) {
            return 1;
        }
        for (int i = 0; i < 24 && !ret; ++i)
            if (dyn->insts[ninst].e.extcache[i].v) { // there is something at ninst for i
                if (!(
                        (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_F
                            || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_D
                            || dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_ST_I64)
                        && dyn->insts[ninst].e.extcache[i].n < dyn->insts[ninst].e.stack_pop))
                    ret = 1;
            }
        for (int i = 0; i < 24 && !ret; ++i)
            if (dyn->insts[0].e.extcache[i].v)
                ret = 1;
        return ret;
    }
    // Check if ninst can be compatible to i2
    if (dyn->insts[ninst].e.stack_next != dyn->insts[i2].e.stack - dyn->insts[i2].e.stack_push) {
        return 1;
    }
    extcache_t cache_i2 = dyn->insts[i2].e;
    extcacheUnwind(&cache_i2);
    sse_restore_entry_ymm0(dyn, &cache_i2, i2);

    for (int i = 0; i < 24; ++i) {
        if (dyn->insts[ninst].e.extcache[i].v) { // there is something at ninst for i
            if (!cache_i2.extcache[i].v) {       // but there is nothing at i2 for i
                ret = 1;
            } else if (dyn->insts[ninst].e.extcache[i].v != cache_i2.extcache[i].v) { // there is something different
                if (dyn->insts[ninst].e.extcache[i].n != cache_i2.extcache[i].n) {    // not the same x64 reg
                    ret = 1;
                } else if (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_XMMR && cache_i2.extcache[i].t == EXT_CACHE_XMMW) { /* nothing */
                } else if (dyn->insts[ninst].e.extcache[i].t == EXT_CACHE_YMMR && cache_i2.extcache[i].t == EXT_CACHE_YMMW) { /* nothing */
                } else
                    ret = 1;
            }
        } else if (cache_i2.extcache[i].v)
            ret = 1;
    }
    return ret;
}

int sewNeedsTransform(dynarec_rv64_t* dyn, int ninst)
{
    int i2 = dyn->insts[ninst].x64.jmp_insts;

    if (dyn->insts[i2].vector_sew_entry == VECTOR_SEWNA)
        return 0;
    else if (dyn->insts[i2].vector_sew_entry == VECTOR_SEWANY && dyn->insts[ninst].vector_sew_exit != VECTOR_SEWNA)
        return 0;
    else if (dyn->insts[i2].vector_sew_entry == dyn->insts[ninst].vector_sew_exit)
        return 0;

    return 1;
}

void extcacheUnwind(extcache_t* cache)
{
    if (!cache->swapped && !cache->news && !cache->stack_push && !cache->stack_pop) {
        int dirty = 0;
        for (int i = 0; i < 16; ++i)
            if (cache->olds[i].v) {
                dirty = 1;
                break;
            }
        if (!dirty) {
            cache->barrier = 0;
            cache->fpu_scratch = 0;
            return;
        }
    }
    if (cache->swapped) {
        // unswap
        int a = -1;
        int b = -1;
        for (int j = 0; j < 24 && ((a == -1) || (b == -1)); ++j)
            if ((cache->extcache[j].t == EXT_CACHE_ST_D
                    || cache->extcache[j].t == EXT_CACHE_ST_F
                    || cache->extcache[j].t == EXT_CACHE_ST_I64)) {
                if (cache->extcache[j].n == cache->combined1)
                    a = j;
                else if (cache->extcache[j].n == cache->combined2)
                    b = j;
            }
        if (a != -1 && b != -1) {
            int tmp = cache->extcache[a].n;
            cache->extcache[a].n = cache->extcache[b].n;
            cache->extcache[b].n = tmp;
        }
        cache->swapped = 0;
        cache->combined1 = cache->combined2 = 0;
    }
    if (cache->news) {
        // remove the newly created extcache
        for (int i = 0; i < 24; ++i)
            if (cache->news & (1u << i))
                cache->extcache[i].v = 0;
        cache->news = 0;
    }
    // add/change bad regs
    for (int i = 0; i < 16; ++i) {
        if (cache->olds[i].v) {
            cache->extcache[i] = cache->olds[i];
            // the undo log has been applied, don't reapply it on a second unwind
            cache->olds[i].v = 0;
        }
    }

    if (cache->stack_push) {
        // unpush
        for (int j = 0; j < 24; ++j) {
            if ((cache->extcache[j].t == EXT_CACHE_ST_D
                    || cache->extcache[j].t == EXT_CACHE_ST_F
                    || cache->extcache[j].t == EXT_CACHE_ST_I64)) {
                if (cache->extcache[j].n < cache->stack_push)
                    cache->extcache[j].v = 0;
                else
                    cache->extcache[j].n -= cache->stack_push;
            }
        }
        cache->x87stack -= cache->stack_push;
        cache->tags >>= (cache->stack_push * 2);
        cache->stack -= cache->stack_push;
        if (cache->pushed >= cache->stack_push)
            cache->pushed -= cache->stack_push;
        else
            cache->pushed = 0;
        cache->stack_push = 0;
    }
    cache->x87stack += cache->stack_pop;
    cache->stack_next = cache->stack;
    if (cache->stack_pop) {
        if (cache->poped >= cache->stack_pop)
            cache->poped -= cache->stack_pop;
        else
            cache->poped = 0;
        cache->tags <<= (cache->stack_pop * 2);
    }
    cache->stack_pop = 0;
    cache->barrier = 0;
    // And now, rebuild the x87cache info with extcache
    cache->mmxcount = 0;
    cache->fpu_scratch = 0;
    for (int i = 0; i < 8; ++i) {
        cache->x87cache[i] = -1;
        cache->mmxcache[i].v = -1;
        cache->x87reg[i] = 0;
        cache->ssecache[i * 2].v = -1;
        cache->ssecache[i * 2 + 1].v = -1;
    }
    int x87reg = 0;
    for (int i = 0; i < 32; ++i) {
        if (cache->extcache[i].v) {
            cache->fpuused[i] = 1;
            switch (cache->extcache[i].t) {
                case EXT_CACHE_MM:
                case EXT_CACHE_MMV:
                    cache->mmxcache[cache->extcache[i].n].reg = EXTREG(i);
                    cache->mmxcache[cache->extcache[i].n].vector = cache->extcache[i].t == EXT_CACHE_MMV;
                    ++cache->mmxcount;
                    break;
                case EXT_CACHE_SS:
                    cache->ssecache[cache->extcache[i].n].reg = EXTREG(i);
                    cache->ssecache[cache->extcache[i].n].vector = 0;
                    cache->ssecache[cache->extcache[i].n].single = 1;
                    break;
                case EXT_CACHE_SD:
                    cache->ssecache[cache->extcache[i].n].reg = EXTREG(i);
                    cache->ssecache[cache->extcache[i].n].vector = 0;
                    cache->ssecache[cache->extcache[i].n].single = 0;
                    break;
                case EXT_CACHE_XMMR:
                case EXT_CACHE_XMMW:
                case EXT_CACHE_YMMR:
                case EXT_CACHE_YMMW:
                    cache->ssecache[cache->extcache[i].n].reg = EXTREG(i);
                    cache->ssecache[cache->extcache[i].n].vector = 1;
                    cache->ssecache[cache->extcache[i].n].write = (cache->extcache[i].t == EXT_CACHE_XMMW || cache->extcache[i].t == EXT_CACHE_YMMW) ? 1 : 0;
                    cache->ssecache[cache->extcache[i].n].ymm = (cache->extcache[i].t == EXT_CACHE_YMMR || cache->extcache[i].t == EXT_CACHE_YMMW) ? 1 : cache->extcache[i].y;
                    cache->ssecache[cache->extcache[i].n].ymm0 = (cache->ymm0 >> cache->extcache[i].n) & 1;
                    break;
                case EXT_CACHE_ST_F:
                case EXT_CACHE_ST_D:
                case EXT_CACHE_ST_I64:
                    cache->x87cache[x87reg] = cache->extcache[i].n;
                    cache->x87reg[x87reg] = EXTREG(i);
                    ++x87reg;
                    break;
                case EXT_CACHE_SCR:
                    cache->fpuused[i] = 0;
                    cache->extcache[i].v = 0;
                    break;
            }
        } else {
            cache->fpuused[i] = 0;
        }
    }
    sse_sync_all_cache_types(cache);
}

// will go badly if address is unaligned
static uint8_t extract_byte(uint32_t val, void* address)
{
    int idx = (((uintptr_t)address) & 3) * 8;
    return (val >> idx) & 0xff;
}

static uint32_t insert_byte(uint32_t val, uint8_t b, void* address)
{
    int idx = (((uintptr_t)address) & 3) * 8;
    val &= ~(0xff << idx);
    val |= (((uint32_t)b) << idx);
    return val;
}

static uint16_t extract_half(uint32_t val, void* address)
{
    int idx = (((uintptr_t)address) & 3) * 8;
    return (val >> idx) & 0xffff;
}
static uint32_t insert_half(uint32_t val, uint16_t h, void* address)
{
    int idx = (((uintptr_t)address) & 3) * 8;
    val &= ~(0xffff << idx);
    val |= (((uint32_t)h) << idx);
    return val;
}

uint8_t rv64_lock_xchg_b(void* addr, uint8_t val)
{
    uint32_t ret;
    uint32_t* aligned = (uint32_t*)(((uintptr_t)addr) & ~3);
    do {
        ret = *aligned;
    } while (rv64_lock_cas_d(aligned, ret, insert_byte(ret, val, addr)));
    return extract_byte(ret, addr);
}

int rv64_lock_cas_b(void* addr, uint8_t ref, uint8_t val)
{
    uint32_t* aligned = (uint32_t*)(((uintptr_t)addr) & ~3);
    uint32_t tmp = *aligned;
    return rv64_lock_cas_d(aligned, insert_byte(tmp, ref, addr), insert_byte(tmp, val, addr));
}

int rv64_lock_cas_h(void* addr, uint16_t ref, uint16_t val)
{
    uint32_t* aligned = (uint32_t*)(((uintptr_t)addr) & ~3);
    uint32_t tmp = *aligned;
    return rv64_lock_cas_d(aligned, insert_half(tmp, ref, addr), insert_half(tmp, val, addr));
}


const char* getCacheName(int t, int n)
{
    static char buff[20];
    switch (t) {
        case EXT_CACHE_ST_D: sprintf(buff, "ST%d", n); break;
        case EXT_CACHE_ST_F: sprintf(buff, "st%d", n); break;
        case EXT_CACHE_ST_I64: sprintf(buff, "STi%d", n); break;
        case EXT_CACHE_MM: sprintf(buff, "MM%d", n); break;
        case EXT_CACHE_MMV: sprintf(buff, "MMV%d", n); break;
        case EXT_CACHE_SS: sprintf(buff, "SS%d", n); break;
        case EXT_CACHE_SD: sprintf(buff, "SD%d", n); break;
        case EXT_CACHE_SCR: sprintf(buff, "Scratch"); break;
        case EXT_CACHE_XMMW: sprintf(buff, "XMM%d", n); break;
        case EXT_CACHE_XMMR: sprintf(buff, "xmm%d", n); break;
        case EXT_CACHE_YMMW: sprintf(buff, "YMM%d", n); break;
        case EXT_CACHE_YMMR: sprintf(buff, "ymm%d", n); break;
        case EXT_CACHE_NONE: buff[0] = '\0'; break;
    }
    return buff;
}

static register_mapping_t register_mappings[] = {
    { "rax", "a6" },
    { "eax", "a6" },
    { "ax", "a6" },
    { "ah", "a6" },
    { "al", "a6" },
    { "rcx", "a3" },
    { "ecx", "a3" },
    { "cx", "a3" },
    { "ch", "a3" },
    { "cl", "a3" },
    { "rdx", "a2" },
    { "edx", "a2" },
    { "dx", "a2" },
    { "dh", "a2" },
    { "dl", "a2" },
    { "rbx", "s8" },
    { "ebx", "s8" },
    { "bx", "s8" },
    { "bh", "s8" },
    { "bl", "s8" },
    { "rsi", "a1" },
    { "esi", "a1" },
    { "si", "a1" },
    { "sil", "a1" },
    { "rdi", "a0" },
    { "edi", "a0" },
    { "di", "a0" },
    { "dil", "a0" },
    { "rsp", "s1" },
    { "esp", "s1" },
    { "sp", "s1" },
    { "spl", "s1" },
    { "rbp", "s0" },
    { "ebp", "s0" },
    { "bp", "s0" },
    { "bpl", "s0" },
    { "r8", "a4" },
    { "r8d", "a4" },
    { "r8w", "a4" },
    { "r8b", "a4" },
    { "r9", "a5" },
    { "r9d", "a5" },
    { "r9w", "a5" },
    { "r9b", "a5" },
    { "r10", "s10" },
    { "r10d", "s10" },
    { "r10w", "s10" },
    { "r10b", "s10" },
    { "r11", "s11" },
    { "r11d", "s11" },
    { "r11w", "s11" },
    { "r11b", "s11" },
    { "r12", "s2" },
    { "r12d", "s2" },
    { "r12w", "s2" },
    { "r12b", "s2" },
    { "r13", "s3" },
    { "r13d", "s3" },
    { "r13w", "s3" },
    { "r13b", "s3" },
    { "r14", "s4" },
    { "r14d", "s4" },
    { "r14w", "s4" },
    { "r14b", "s4" },
    { "r15", "s5" },
    { "r15d", "s5" },
    { "r15w", "s5" },
    { "r15b", "s5" },
    { "rip", "s6" },
};

static const char* df_status[] = { "unknown", "set", "none_pending", "none" };

void printf_x64_instruction(dynarec_native_t* dyn, zydis_dec_t* dec, instruction_x64_t* inst, const char* name);
void inst_name_pass3(dynarec_native_t* dyn, int ninst, const char* name, rex_t rex)
{
    if (dyn->need_dump == 3) {
        printf_x64_instruction(dyn, rex.is32bits ? my_context->dec32 : my_context->dec, &dyn->insts[ninst].x64, name);
        if (!BOX64ENV(dynarec_gdbjit) && !BOX64ENV(dynarec_perf_map)) return;
    }
    if (!dyn->need_dump && !BOX64ENV(dynarec_gdbjit) && !BOX64ENV(dynarec_perf_map)) return;

    static char buf[65536];
    int length = sprintf(buf, "barrier=%d state=%d/%s(%s->%s), set=%X/%X, use=%X, need=%X/%X, fuse=%d/%d, sm=%d(%d/%d), sew@entry=%d, sew@exit=%d",
        dyn->insts[ninst].x64.barrier,
        dyn->insts[ninst].x64.state_flags,
        df_status[dyn->f],
        df_status[dyn->insts[ninst].f_entry],
        df_status[dyn->insts[ninst].f_exit],
        dyn->insts[ninst].x64.set_flags,
        dyn->insts[ninst].x64.gen_flags,
        dyn->insts[ninst].x64.use_flags,
        dyn->insts[ninst].x64.need_before,
        dyn->insts[ninst].x64.need_after,
        dyn->insts[ninst].nat_flags_fusion,
        dyn->insts[ninst].no_scratch_usage,
        dyn->smwrite, dyn->insts[ninst].will_write, dyn->insts[ninst].last_write,
        dyn->insts[ninst].vector_sew_entry, dyn->insts[ninst].vector_sew_exit);
    if (dyn->insts[ninst].pred_sz) {
        length += sprintf(buf + length, ", pred=");
        for (int ii = 0; ii < dyn->insts[ninst].pred_sz; ++ii)
            length += sprintf(buf + length, "%s%d", ii ? "/" : "", dyn->insts[ninst].pred[ii]);
    }
    if (dyn->insts[ninst].x64.jmp && dyn->insts[ninst].x64.jmp_insts >= 0)
        length += sprintf(buf + length, ", jmp=%d", dyn->insts[ninst].x64.jmp_insts);
    if (dyn->insts[ninst].x64.jmp && dyn->insts[ninst].x64.jmp_insts == -1)
        length += sprintf(buf + length, ", jmp=out");
    if (dyn->last_ip)
        length += sprintf(buf + length, ", last_ip=%p", (void*)dyn->last_ip);
    for (int ii = 0; ii < 32; ++ii) {
        switch (dyn->insts[ninst].e.extcache[ii].t) {
            case EXT_CACHE_ST_D: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_ST_F: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_ST_I64: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_MM: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_MMV: length += sprintf(buf + length, " v%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_SS: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_SD: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_XMMR: length += sprintf(buf + length, " v%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_XMMW: length += sprintf(buf + length, " v%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_YMMR: length += sprintf(buf + length, " v%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_YMMW: length += sprintf(buf + length, " v%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_SCR: length += sprintf(buf + length, " f%d:%s", EXTREG(ii), getCacheName(dyn->insts[ninst].e.extcache[ii].t, dyn->insts[ninst].e.extcache[ii].n)); break;
            case EXT_CACHE_NONE:
            default: break;
        }
    }
    if (dyn->ymm_zero)
        length += sprintf(buf + length, " ymm0_mask = %04x", dyn->ymm_zero);
    if (dyn->e.stack || dyn->insts[ninst].e.stack_next || dyn->insts[ninst].e.x87stack)
        length += sprintf(buf + length, " X87:%d/%d(+%d/-%d)%d", dyn->e.stack, dyn->insts[ninst].e.stack_next, dyn->insts[ninst].e.stack_push, dyn->insts[ninst].e.stack_pop, dyn->insts[ninst].e.x87stack);
    if (dyn->insts[ninst].e.combined1 || dyn->insts[ninst].e.combined2)
        length += sprintf(buf + length, " %s:%d/%d", dyn->insts[ninst].e.swapped ? "SWP" : "CMB", dyn->insts[ninst].e.combined1, dyn->insts[ninst].e.combined2);

    if (dyn->need_dump && dyn->need_dump != 3) {
        printf_x64_instruction(dyn, rex.is32bits ? my_context->dec32 : my_context->dec, &dyn->insts[ninst].x64, name);
        dynarec_log(LOG_NONE, "%s%p: %d emitted opcodes, inst=%d, %s%s\n",
            (dyn->need_dump > 1) ? "\e[32m" : "",
            (void*)(dyn->native_start + dyn->insts[ninst].address), dyn->insts[ninst].size / 4, ninst, buf, (dyn->need_dump > 1) ? "\e[m" : "");
    }
    if (BOX64ENV(dynarec_gdbjit)) {
        static char buf2[4096 + 64];
        if (BOX64ENV(dynarec_gdbjit) > 1) {
            snprintf(buf2, sizeof(buf2), "; %d: %d opcodes, %s", ninst, dyn->insts[ninst].size / 4, buf);
            dyn->gdbjit_block = GdbJITBlockAddLine(dyn->gdbjit_block, (dyn->native_start + dyn->insts[ninst].address), buf2);
        }
        zydis_dec_t* dec = rex.is32bits ? my_context->dec32 : my_context->dec;
        const char* inst_name = name;
        if (dec) {
            inst_name = DecodeX64Trace(dec, dyn->insts[ninst].x64.addr, 0);
            x64disas_add_register_mapping_annotations(buf2, inst_name, register_mappings, sizeof(register_mappings) / sizeof(register_mappings[0]));
            inst_name = buf2;
        }
        dyn->gdbjit_block = GdbJITBlockAddLine(dyn->gdbjit_block, (dyn->native_start + dyn->insts[ninst].address), inst_name);
    }
    if (BOX64ENV(dynarec_perf_map) && BOX64ENV(dynarec_perf_map_fd) != -1) {
        writePerfMap(dyn->insts[ninst].x64.addr, dyn->native_start + dyn->insts[ninst].address, dyn->insts[ninst].size, name);
    }
    if (length > sizeof(buf)) printf_log(LOG_NONE, "Warning: buf to small in inst_name_pass3 (%d vs %zd)\n", length, sizeof(buf));
}

void print_opcode(dynarec_native_t* dyn, int ninst, uint32_t opcode)
{
    dynarec_log_prefix(0, LOG_NONE, "\t%08x\t%s\n", opcode, rv64_print(opcode, (uintptr_t)dyn->block));
}

// x87 stuffs
static void x87_reset(extcache_t* e)
{
    for (int i = 0; i < 8; ++i)
        e->x87cache[i] = -1;
    e->x87stack = 0;
    e->stack = 0;
    e->stack_next = 0;
    e->stack_pop = 0;
    e->stack_push = 0;
    e->combined1 = e->combined2 = 0;
    e->swapped = 0;
    e->barrier = 0;
    e->pushed = 0;
    e->poped = 0;

    for (int i = 0; i < 24; ++i)
        if (e->extcache[i].t == EXT_CACHE_ST_F
            || e->extcache[i].t == EXT_CACHE_ST_D
            || e->extcache[i].t == EXT_CACHE_ST_I64)
            e->extcache[i].v = 0;
}

static void mmx_reset(extcache_t* e)
{
    e->mmxcount = 0;
    for (int i = 0; i < 8; ++i)
        e->mmxcache[i].v = -1;
}

static void sse_reset(extcache_t* e)
{
    for (int i = 0; i < 16; ++i)
        e->ssecache[i].v = -1;
}

void fpu_reset(dynarec_rv64_t* dyn)
{
    x87_reset(&dyn->e);
    mmx_reset(&dyn->e);
    sse_reset(&dyn->e);
    fpu_reset_reg(dyn);
    dyn->ymm_zero = 0;
}

void fpu_reset_ninst(dynarec_rv64_t* dyn, int ninst)
{
    x87_reset(&dyn->insts[ninst].e);
    mmx_reset(&dyn->insts[ninst].e);
    sse_reset(&dyn->insts[ninst].e);
    fpu_reset_reg_extcache(dyn, &dyn->insts[ninst].e);
}

int fpu_is_st_freed(dynarec_rv64_t* dyn, int ninst, int st)
{
    return (dyn->e.tags & (0b11 << (st * 2))) ? 1 : 0;
}

static int hasLinearPredecessor(const dynarec_rv64_t* dyn, int ninst);

void updateNativeFlags(dynarec_rv64_t* dyn)
{
    if (!BOX64ENV(dynarec_nativeflags))
        return;
    for (int i = 0; i < dyn->size; ++i)
        if (dyn->insts[i].nat_flags_fusion) {
            int j = i - 1;
            int found = 0;
            int last_fused = 0;
            if (hasLinearPredecessor(dyn, i)) {
                while (j >= 0) {
                    if (dyn->insts[j].x64.set_flags && (dyn->insts[i].x64.use_flags & dyn->insts[j].x64.set_flags) == dyn->insts[i].x64.use_flags) {
                        int needsign = (dyn->insts[i].x64.use_flags & X_SF) ? 1 : 0;
                        int needunsigned = (dyn->insts[i].x64.use_flags & X_CF) ? 1 : 0;
                        if (dyn->insts[j].nat_flags_fusion && ((needsign && dyn->insts[j].nat_flags_needunsigned) || (needunsigned && dyn->insts[j].nat_flags_needsign)))
                            break; // not compatible, stop here
                        dyn->insts[j].nat_flags_fusion = 1;
                        if (needsign)
                            dyn->insts[j].nat_flags_needsign = 1;
                        if (needunsigned)
                            dyn->insts[j].nat_flags_needunsigned = 1;
                        dyn->insts[i].x64.use_flags = 0;
                        if (last_fused) {
                            dyn->insts[last_fused].nat_next_inst = i;
                        } else {
                            uint16_t* next = &dyn->insts[j].nat_next_inst;
                            while (*next)
                                next = &dyn->insts[*next].nat_next_inst;
                            *next = i;
                        }
                        dyn->insts[i].up32_read |= dyn->insts[j].up32_write32;
                        found = 1;
                        break;
                    } else if (hasLinearPredecessor(dyn, j) && dyn->insts[j].nat_flags_fusion && dyn->insts[j].x64.jmp && !dyn->insts[j].x64.set_flags && !dyn->insts[j].x64.use_flags) {
                        // already fused Jcc consumer
                        if (!last_fused) last_fused = j;
                        j -= 1;
                    } else if (hasLinearPredecessor(dyn, j) && dyn->insts[j].no_scratch_usage && !dyn->insts[j].x64.set_flags && !dyn->insts[j].x64.use_flags) {
                        j -= 1;
                    } else
                        break;
                }
            }
            if (!found) dyn->insts[i].nat_flags_fusion = 0;
        }
}

void get_free_scratch(dynarec_rv64_t* dyn, int ninst, uint8_t* tmp1, uint8_t* tmp2, uint8_t* tmp3, uint8_t s1, uint8_t s2, uint8_t s3, uint8_t s4, uint8_t s5)
{
    uint8_t n1 = dyn->insts[ninst].nat_flags_op1;
    uint8_t n2 = dyn->insts[ninst].nat_flags_op2;
    uint8_t tmp[5] = { 0 };
    int idx = 0;
#define GO(s) \
    if ((s != n1) && (s != n2)) tmp[idx++] = s
    GO(s1);
    GO(s2);
    GO(s3);
    GO(s4);
    GO(s5);
#undef GO
    *tmp1 = tmp[0];
    *tmp2 = tmp[1];
    *tmp3 = tmp[2];
}

void fpu_save_and_unwind(dynarec_rv64_t* dyn, int ninst, extcache_t* cache)
{
    memcpy(cache, &dyn->insts[ninst].e, sizeof(extcache_t));
    extcacheUnwind(&dyn->insts[ninst].e);
}
void fpu_unwind_restore(dynarec_rv64_t* dyn, int ninst, extcache_t* cache)
{
    memcpy(&dyn->insts[ninst].e, cache, sizeof(extcache_t));
}

static int hasLinearPredecessor(const dynarec_rv64_t* dyn, int ninst)
{
    return ninst > 0 && dyn->insts[ninst].pred_sz == 1 && dyn->insts[ninst].pred[0] == ninst - 1;
}

int isUpper32Zero(dynarec_rv64_t* dyn, int ninst, int reg)
{
    if (!IS_GPR(reg))
        return 0;

    const uint16_t bit = (uint16_t)(1 << TO_X64(reg));
    int current = ninst;
    for (int depth = 0; depth < 4 && hasLinearPredecessor(dyn, current); ++depth) {
        const instruction_rv64_t* prev = &dyn->insts[current - 1];
        if (prev->x64.has_callret || prev->x64.barrier)
            return 0;
        if (prev->up32_write64 & bit) return prev->up32_zero & bit;
        --current;
    }
    return 0;
}

static uint32_t getUsedVectorMask(const dynarec_rv64_t* dyn, int first, int last)
{
    uint32_t ret = 0;
    for (int i = first; i <= last && i < dyn->size; ++i)
        ret |= dyn->insts[i].vec_used;
    return ret;
}

static int getFirstVectorUse(const dynarec_rv64_t* dyn, int first, int last, int reg)
{
    for (int i = first; i <= last && i < dyn->size; ++i)
        if (dyn->insts[i].vec_used & (1u << reg))
            return i;
    return -1;
}

static void applyPreloadState(dynarec_rv64_t* dyn, int first, int first_use, int reg)
{
    for (int i = first; i < first_use; ++i) {
        extcache_t* e = &dyn->insts[i].e;
        sse_cache_t* s = &e->ssecache[reg];
        s->reg = VREG(reg);
        s->vector = 1;
        s->single = 0;
        s->write = 0;
        s->ymm = 0;
        s->ymm0 = (e->ymm0 >> reg) & 1;
        e->fpuused[EXTIDX(VREG(reg))] = 1;
        e->extcache[EXTIDX(VREG(reg))].n = reg;
        e->extcache[EXTIDX(VREG(reg))].y = 0;
        sse_sync_cache_type(e, reg);
    }
}

void updatePreloads(dynarec_rv64_t* dyn)
{
    if (!cpuext.vector)
        return;
    for (int first = 0; first < dyn->size; ++first) {
        if (dyn->insts[first].preload_xmmymm)
            continue;
        if (first)
            break;
        if (!dyn->insts[first].pred_sz)
            continue;
        int last = dyn->size + 1;
        for (int j = 0; j < dyn->insts[first].pred_sz; ++j) {
            int pred = dyn->insts[first].pred[j];
            if (pred != first - 1 && pred < last)
                last = pred;
        }
        if (last > dyn->size || last <= first)
            continue;
        if (first && !dyn->insts[first - 1].x64.has_next)
            continue;
        int straight = 1;
        for (int i = first; i < last && straight; ++i) {
            const instruction_rv64_t* inst = &dyn->insts[i];
            if (!inst->x64.has_next || (inst->x64.barrier & BARRIER_FLOAT)
                || inst->x64.has_callret)
                straight = 0;
        }
        if (!straight)
            continue;
        uint32_t preload = getUsedVectorMask(dyn, first, last);
        if (!preload)
            continue;
        uint32_t accepted = 0;
        for (int reg = 0; reg < 16; ++reg) {
            if (!(preload & (1u << reg)))
                continue;
            int first_use = getFirstVectorUse(dyn, first, last, reg);
            if (first_use < 0)
                continue;
            int ok = 1;
            int prev = first - 1;
            if (prev >= 0 && dyn->insts[prev].e.ssecache[reg].v != -1)
                ok = 0;
            for (int i = first; i < first_use && ok; ++i)
                if (dyn->insts[i].e.ssecache[reg].v != -1)
                    ok = 0;
            if (ok && dyn->insts[first_use].e.ssecache[reg].v == -1)
                ok = 0;
            if (!ok)
                continue;
            applyPreloadState(dyn, first, first_use, reg);
            accepted |= 1u << reg;
        }
        if (accepted)
            dyn->insts[first].preload_xmmymm = accepted;
    }
}

void updateUpperLiveness(dynarec_rv64_t* dyn)
{
    int n = dyn->size;
    if (n <= 0)
        return;

    size_t live_size = (size_t)n * sizeof(uint16_t);
    size_t pending_size = (size_t)n * sizeof(uint16_t);
    size_t work_size = (size_t)n * sizeof(int);
    size_t list_size = (size_t)n * sizeof(uint8_t);
    void* buffer = calloc(1, 5 * live_size + pending_size + work_size + list_size);
    if (!buffer)
        return;
    uint16_t* live_in = (uint16_t*)buffer;
    uint16_t* live_out = (uint16_t*)((char*)live_in + live_size);
    uint16_t* live_ymm_in = (uint16_t*)((char*)live_out + live_size);
    uint16_t* live_ymm_out = (uint16_t*)((char*)live_ymm_in + live_size);
    uint16_t* pending_in = (uint16_t*)((char*)live_ymm_out + live_size);
    uint16_t* pend_ymm = (uint16_t*)((char*)pending_in + pending_size);
    int* work = (int*)((char*)pend_ymm + live_size);
    uint8_t* on_list = (uint8_t*)((char*)work + work_size);

    for (int i = 0; i < n; ++i) {
        instruction_rv64_t* inst = &dyn->insts[i];
        inst->promote_ymm = 0;
        if (!inst->x64.alive || inst->pred_sz < 2 || (inst->x64.barrier & BARRIER_FLOAT))
            continue;
        const extcache_t* first = &dyn->insts[inst->pred[0]].e;
        uint16_t promote = 0;
        int need_barrier = 0;
        for (int p = 1; p < inst->pred_sz && !need_barrier; ++p) {
            const extcache_t* pe = &dyn->insts[inst->pred[p]].e;
            uint16_t mask_diff = (uint16_t)(first->ymm0 ^ pe->ymm0);
            uint16_t resolved = 0;
            for (int r = 0; r < 16; ++r) {
                const sse_cache_t* a = &first->ssecache[r];
                const sse_cache_t* b = &pe->ssecache[r];
                int a_cached = (a->v != -1 && a->vector);
                int b_cached = (b->v != -1 && b->vector);
                if (!a_cached || !b_cached)
                    continue;
                if (a->ymm == b->ymm && a->ymm0 == b->ymm0)
                    continue;
                int a_ok = a->ymm || (!a->ymm && a->ymm0);
                int b_ok = b->ymm || (!b->ymm && b->ymm0);
                if (a_ok && b_ok) {
                    if (!a->ymm) promote |= (uint16_t)(1u << r);
                    if (!b->ymm) promote |= (uint16_t)(1u << r);
                    resolved |= (uint16_t)(1u << r);
                    continue;
                }
                need_barrier = 1;
                break;
            }
            if (mask_diff & (uint16_t)~resolved)
                need_barrier = 1;
        }
        if (need_barrier)
            inst->x64.barrier |= BARRIER_FLOAT;
        else
            inst->promote_ymm = promote;
    }

    int sp = 0;
    for (int i = n - 1; i >= 0; --i) {
        if (dyn->insts[i].x64.alive) {
            work[sp++] = i;
            on_list[i] = 1;
        }
    }
    // backward analysis
    while (sp > 0) {
        int i = work[--sp];
        on_list[i] = 0;
        const instruction_rv64_t* inst = &dyn->insts[i];
        if (!inst->x64.alive)
            continue;
        uint16_t combined_out = 0;
        if (inst->x64.has_next && i + 1 < n && dyn->insts[i + 1].x64.alive)
            combined_out |= live_in[i + 1];
        if (inst->x64.jmp) {
            if (inst->x64.jmp_insts >= 0 && inst->x64.jmp_insts < n)
                combined_out |= live_in[inst->x64.jmp_insts];
            else
                combined_out = UINT16_MAX;
        }
        int has_internal_jump = inst->x64.jmp && inst->x64.jmp_insts >= 0 && inst->x64.jmp_insts < n;
        if ((inst->x64.has_next && i == n - 1) || (!inst->x64.has_next && !has_internal_jump))
            combined_out = UINT16_MAX;
        live_out[i] = combined_out;

        uint16_t combined_ymm_out = 0;
        if (inst->x64.has_next && i + 1 < n && dyn->insts[i + 1].x64.alive)
            combined_ymm_out |= live_ymm_in[i + 1];
        if (inst->x64.jmp && inst->x64.jmp_insts >= 0 && inst->x64.jmp_insts < n)
            combined_ymm_out |= live_ymm_in[inst->x64.jmp_insts];
        if ((!inst->x64.has_next && !has_internal_jump) || (inst->x64.jmp && inst->x64.jmp_insts < 0))
            combined_ymm_out = UINT16_MAX;
        live_ymm_out[i] = combined_ymm_out;

        uint16_t live_ymm_in_val = inst->ymm_upper_use | (combined_ymm_out & (uint16_t)~inst->ymm_upper_def);
        if ((inst->x64.barrier & BARRIER_FLOAT) || inst->x64.has_callret)
            live_ymm_in_val = UINT16_MAX;

        uint16_t live_in_val = inst->up32_read | (combined_out & (uint16_t)~inst->up32_write64);
        if ((live_in_val != live_in[i]) || (live_ymm_in_val != live_ymm_in[i])) {
            live_in[i] = live_in_val;
            live_ymm_in[i] = live_ymm_in_val;
            for (int p = 0; p < inst->pred_sz; ++p) {
                int j = inst->pred[p];
                if (!on_list[j]) {
                    work[sp++] = j;
                    on_list[j] = 1;
                }
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        instruction_rv64_t* inst = &dyn->insts[i];
        inst->up32_skip = inst->up32_write32 & (uint16_t)~live_out[i];
        inst->ymm_upper_live = live_ymm_out[i];
    }

    // forward analysis
    memset(pending_in, 0, pending_size);
    memset(pend_ymm, 0, live_size);
    memset(on_list, 0, list_size);
    sp = 0;
    for (int i = 0; i < n; ++i) {
        if (dyn->insts[i].x64.alive) {
            work[sp++] = i;
            on_list[i] = 1;
        }
    }
    while (sp > 0) {
        int i = work[--sp];
        on_list[i] = 0;
        instruction_rv64_t* inst = &dyn->insts[i];
        if (!inst->x64.alive)
            continue;

        uint16_t merged_pending = 0;
        uint16_t merged_ymm = 0;
        for (int p = 0; p < inst->pred_sz; ++p) {
            int j = inst->pred[p];
            const instruction_rv64_t* pred = &dyn->insts[j];
            merged_pending |= (pending_in[j] & (uint16_t)~pred->up32_write64) | pred->up32_skip;
            uint16_t ymm_def = pred->ymm_pending_materialized ? UINT16_MAX : pred->ymm_upper_def;
            merged_ymm |= (pend_ymm[j] & (uint16_t)~ymm_def) | (pred->ymm_zero & pred->ymm_upper_live);
        }
        if (inst->x64.barrier & BARRIER_FLOAT) merged_ymm = 0;
        merged_ymm &= (uint16_t)~inst->promote_ymm;
        if ((merged_pending != pending_in[i]) || (merged_ymm != pend_ymm[i])) {
            pending_in[i] = merged_pending;
            pend_ymm[i] = merged_ymm;
            if (inst->x64.has_next && i + 1 < n && dyn->insts[i + 1].x64.alive && !on_list[i + 1]) {
                work[sp++] = i + 1;
                on_list[i + 1] = 1;
            }
            if (inst->x64.jmp && inst->x64.jmp_insts >= 0 && inst->x64.jmp_insts < n) {
                int j = inst->x64.jmp_insts;
                if (dyn->insts[j].x64.alive && !on_list[j]) {
                    work[sp++] = j;
                    on_list[j] = 1;
                }
            }
        }
    }
    for (int i = 0; i < n; ++i) {
        dyn->insts[i].up32_pending = pending_in[i];
        dyn->insts[i].ymm_pending = pend_ymm[i];
    }

    free(buffer);
}

void updateRspMerge(dynarec_rv64_t* dyn, int is32bits)
{
    const int delta = is32bits ? 4 : 8;
    int pending = 0;
    int last_pushpop = -1;
    for (int i = 0; i < dyn->size; ++i) {
        instruction_rv64_t* inst = &dyn->insts[i];
        inst->rsp_entry = 0;
        inst->rsp_flush = 0;
        inst->rsp_merge = 0;
        int class = (inst->x64.alive && !BOX64ENV(dynarec_test)) ? inst->rsp_class : RSP_CLASS_BARRIER;
        if (pending && (class == RSP_CLASS_BARRIER || (i == 0) || (inst->pred_sz != 1) || (inst->pred[0] != i - 1))) {
            dyn->insts[last_pushpop].rsp_flush = pending;
            pending = 0;
            last_pushpop = -1;
        }
        switch (class) {
            case RSP_CLASS_PUSH:
                if (pending - (inst->rsp_span ? inst->rsp_span : delta) < -2048) {
                    dyn->insts[last_pushpop].rsp_flush = pending;
                    pending = 0;
                }
                inst->rsp_entry = pending;
                inst->rsp_merge = 1;
                pending -= (inst->rsp_span ? inst->rsp_span : delta);
                last_pushpop = i;
                break;
            case RSP_CLASS_POP:
                if (pending + (inst->rsp_span ? inst->rsp_span : delta) > 2047) {
                    dyn->insts[last_pushpop].rsp_flush = pending;
                    pending = 0;
                }
                inst->rsp_entry = pending;
                inst->rsp_merge = 1;
                pending += (inst->rsp_span ? inst->rsp_span : delta);
                last_pushpop = i;
                break;
            default:
                break;
        }
    }
    if (pending) dyn->insts[last_pushpop].rsp_flush = pending;
}
