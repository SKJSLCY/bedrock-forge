// SPDX-License-Identifier: MIT
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>

#include "debug.h"
#include "box64context.h"
#include "box64cpu.h"
#include "emu/x64emu_private.h"
#include "x64emu.h"
#include "box64stack.h"
#include "callback.h"
#include "emu/x64run_private.h"
#include "x64trace.h"
#include "dynarec_native.h"

#include "rv64_printer.h"
#include "dynarec_rv64_private.h"
#include "../dynarec_helper.h"
#include "dynarec_rv64_functions.h"


uintptr_t dynarec64_F0(dynarec_rv64_t* dyn, uintptr_t addr, uintptr_t ip, int ninst, rex_t rex, int* ok, int* need_epilog)
{
    (void)ip;
    (void)need_epilog;

    uint8_t opcode = F8;
    uint8_t nextop;
    uint8_t gd, ed, u8;
    uint8_t wback, wb1, wb2, eb1, eb2, gb1, gb2;
    int32_t i32;
    int64_t i64, j64;
    int64_t fixedaddress;
    int unscaled;
    MAYUSE(eb1);
    MAYUSE(eb2);
    MAYUSE(gb1);
    MAYUSE(gb2);
    MAYUSE(wb1);
    MAYUSE(wb2);
    MAYUSE(j64);

    switch (opcode) {
        case 0x00:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK ADD Eb, Gb");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x1);
                addr = geted(dyn, addr, ninst, nextop, &wback, x6, x7, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x2, wback, 3);
                SLLI(x2, x2, 3);
                ANDI(x3, wback, ~3);
                MARKLOCK;
                LR_W(x4, x3, 1, 1);
                SRL(x5, x4, x2);
                ANDI(x5, x5, 0xFF); // old byte
                ADD(x7, x5, x1);
                ANDI(x7, x7, 0xFF); // new byte
                SLL(x6, x5, x2);
                SUB(x4, x4, x6);
                SLL(x6, x7, x2);
                ADD(x4, x4, x6);
                SC_W(x6, x4, x3, 1, 1);
                BNEZ_MARKLOCK(x6);
                IFXORNAT (X_ALL | X_PEND) {
                    emit_add8(dyn, ninst, x5, x1, x2, x3, x4);
                }
            }
            break;
        case 0x01:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK ADD Ed, Gd");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                AMOADDxw(x1, gd, wback, 1, 1);
                IFXORNAT (X_ALL | X_PEND) {
                    emit_add32(dyn, ninst, rex, x1, gd, x3, x4, x5);
                }
            }
            break;
        case 0x08:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK OR Eb, Gb");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x1);
                addr = geted(dyn, addr, ninst, nextop, &wback, x5, x6, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x2, wback, 3);
                SLLI(x2, x2, 3);
                ANDI(x3, wback, ~3);
                SLL(x6, x1, x2);
                AMOOR_W(x4, x6, x3, 1, 1);
                IFXORNAT (X_ALL | X_PEND) {
                    SRL(x2, x4, x2);
                    ANDI(x2, x2, 0xFF);
                    emit_or8(dyn, ninst, x2, x1, x4, x5);
                }
            }
            break;
        case 0x30:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK XOR Eb, Gb");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x1);
                addr = geted(dyn, addr, ninst, nextop, &wback, x5, x6, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x2, wback, 3);
                SLLI(x2, x2, 3);
                ANDI(x3, wback, ~3);
                SLL(x6, x1, x2);
                AMOXOR_W(x4, x6, x3, 1, 1);
                IFXORNAT (X_ALL | X_PEND) {
                    SRL(x2, x4, x2);
                    ANDI(x2, x2, 0xFF);
                    emit_xor8(dyn, ninst, x2, x1, x4, x5);
                }
            }
            break;
        case 0x09:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK OR Ed, Gd");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                AMOORxw(x1, gd, wback, 1, 1);
                IFXORNAT (X_ALL | X_PEND)
                    emit_or32(dyn, ninst, rex, x1, gd, x3, x4);
            }
            break;

        case 0x0F:
            nextop = F8;
            switch (nextop) {
                case 0xAB:
                    nextop = F8;
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK BTS Ed, Gd");
                        SETFLAGS(X_CF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                        SET_DFNONE();
                        GETGD;
                        addr = geted(dyn, addr, ninst, nextop, &wback, x3, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        if (rex.w)
                            SRAI(x1, gd, 3);
                        else
                            SRAIW(x1, gd, 3);
                        ADD(x2, wback, x1);
                        ANDI(x4, gd, 7);
                        ANDI(x5, x2, 0b11);
                        SLLI(x5, x5, 3);
                        OR(x4, x4, x5);
                        ANDI(x2, x2, ~0b11);
                        ADDI(x5, xZR, 1);
                        SLL(x5, x5, x4);
                        AMOOR_W(x6, x5, x2, 1, 1);
                        SRL(x6, x6, x4);
                        ANDI(x6, x6, 1);
                        ANDI(xFlags, xFlags, ~1);
                        OR(xFlags, xFlags, x6);
                    }
                    break;
                case 0xB0:
                    switch (rex.rep) {
                        case 0:
                            nextop = F8;
                            if (MODREG) {
                                INST_NAME("Invalid LOCK");
                                UDF();
                                *need_epilog = 1;
                                *ok = 0;
                            } else {
                                INST_NAME("LOCK CMPXCHG Eb, Gb");
                                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_NOFUSION);
                                ANDI(x6, xRAX, 0xff); // AL
                                if (rex.rex) {
                                    gb1 = TO_NAT(((nextop & 0x38) >> 3) + (rex.r << 3));
                                    gb2 = 0;
                                } else {
                                    gd = (nextop & 0x38) >> 3;
                                    gb2 = ((gd & 4) >> 2);
                                    gb1 = TO_NAT(gd & 3);
                                }
                                addr = geted(dyn, addr, ninst, nextop, &wback, x3, x2, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                ANDI(x5, wback, 0b11);
                                SLLI(x5, x5, 3); // shamt
                                MARKLOCK;
                                ANDI(x2, wback, ~0b11); // align to 32bit
                                LR_W(x4, x2, 1, 1);
                                MV(x1, x4);
                                SRL(x4, x4, x5);
                                ANDI(x4, x4, 0xff);
                                BNE_MARK(x6, x4); // compare AL with m8
                                // AL == m8, r8 is loaded into m8
                                ADDI(x2, xZR, 0xff);
                                SLL(x2, x2, x5);
                                ANDN(x2, x1, x2, x2);
                                if (gb2) {
                                    SRLI(x1, gb1, 8);
                                    ANDI(x1, x1, 0xff);
                                } else {
                                    ANDI(x1, gb1, 0xff);
                                }
                                SLL(x1, x1, x5);
                                OR(x1, x1, x2);
                                ANDI(x2, wback, ~0b11); // align to 32bit again
                                SC_W(x7, x1, x2, 1, 1);
                                BNEZ_MARKLOCK(x7);
                                // done
                                MARK;
                                UFLAG_IF { emit_cmp8(dyn, ninst, x6, x4, x1, x2, x3, x5); }
                                // load m8 into AL
                                ANDI(xRAX, xRAX, ~0xff);
                                OR(xRAX, xRAX, x4);
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;
                case 0xB1:
                    switch (rex.rep) {
                        case 0:
                            nextop = F8;
                            if (MODREG) {
                                INST_NAME("Invalid LOCK");
                                UDF();
                                *need_epilog = 1;
                                *ok = 0;
                            } else {
                                INST_NAME("LOCK CMPXCHG Ed, Gd");
                                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_NOFUSION);
                                GETGD;
                                MARKREGs(xRAX);
                                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                UFLAG_IF { MVxw(x6, xRAX); }
                                ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                                BNEZ_MARK3(x1);
                                // Aligned
                                MARKLOCK;
                                LRxw(x1, wback, 1, 1);
                                SUBxw(x3, x1, xRAX);
                                BNEZ(x3, 4 + (rex.w ? 8 : 12));
                                // EAX == Ed
                                SCxw(x4, gd, wback, 1, 1);
                                BNEZ_MARKLOCK(x4);
                                if (!rex.w) { B_MARK_nocond; }
                                MVxw(xRAX, x1);
                                B_MARK_nocond;
                                MARK3;
                                // Unaligned
                                ANDI(x5, wback, -(1 << (rex.w + 2)));
                                MARKLOCK2;
                                LDxw(x1, wback, 0);
                                LRxw(x7, x5, 1, 1);
                                SUBxw(x3, x1, xRAX);
                                BNEZ(x3, 4 + (rex.w ? 12 : 16));
                                // EAX == Ed
                                SCxw(x4, x7, x5, 1, 1);
                                BNEZ_MARKLOCK2(x4);
                                SDxw(gd, wback, 0);
                                if (!rex.w) { B_MARK_nocond; }
                                MVxw(xRAX, x1);
                                MARK;
                                UFLAG_IF { emit_cmp32(dyn, ninst, rex, x6, x1, x3, x4, x5, x7); }
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;
                case 0xB3:
                    nextop = F8;
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK BTR Ed, Gd");
                        SETFLAGS(X_CF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                        SET_DFNONE();
                        GETGD;
                        addr = geted(dyn, addr, ninst, nextop, &wback, x3, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        if (rex.w)
                            SRAI(x1, gd, 3);
                        else
                            SRAIW(x1, gd, 3);
                        ADD(x2, wback, x1);
                        ANDI(x4, gd, 7);
                        ANDI(x5, x2, 0b11);
                        SLLI(x5, x5, 3);
                        OR(x4, x4, x5);
                        ANDI(x2, x2, ~0b11);
                        ADDI(x5, xZR, 1);
                        SLL(x5, x5, x4);
                        XORI(x5, x5, -1);
                        AMOAND_W(x6, x5, x2, 1, 1);
                        SRL(x6, x6, x4);
                        ANDI(x6, x6, 1);
                        ANDI(xFlags, xFlags, ~1);
                        OR(xFlags, xFlags, x6);
                    }
                    break;
                case 0xBB:
                    nextop = F8;
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK BTC Ed, Gd");
                        SETFLAGS(X_CF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                        SET_DFNONE();
                        GETGD;
                        addr = geted(dyn, addr, ninst, nextop, &wback, x3, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        if (rex.w)
                            SRAI(x1, gd, 3);
                        else
                            SRAIW(x1, gd, 3);
                        ADD(x2, wback, x1);
                        ANDI(x4, gd, 7);
                        ANDI(x5, x2, 0b11);
                        SLLI(x5, x5, 3);
                        OR(x4, x4, x5);
                        ANDI(x2, x2, ~0b11);
                        ADDI(x5, xZR, 1);
                        SLL(x5, x5, x4);
                        AMOXOR_W(x6, x5, x2, 1, 1);
                        SRL(x6, x6, x4);
                        ANDI(x6, x6, 1);
                        ANDI(xFlags, xFlags, ~1);
                        OR(xFlags, xFlags, x6);
                    }
                    break;
                case 0xBA:
                    switch (rex.rep) {
                        case 0:
                            nextop = F8;
                            switch ((nextop >> 3) & 7) {
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                    if (MODREG) {
                                        INST_NAME("Invalid LOCK");
                                        UDF();
                                        *need_epilog = 1;
                                        *ok = 0;
                                    } else {
                                        if (((nextop >> 3) & 7) == 4)
                                            INST_NAME("LOCK BT Ed, Ib");
                                        else if (((nextop >> 3) & 7) == 5)
                                            INST_NAME("LOCK BTS Ed, Ib");
                                        else if (((nextop >> 3) & 7) == 6)
                                            INST_NAME("LOCK BTR Ed, Ib");
                                        else
                                            INST_NAME("LOCK BTC Ed, Ib");
                                        SETFLAGS(X_CF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                                        SET_DFNONE();
                                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                        u8 = F8;
                                        if (rex.w) u8 &= 63; else u8 &= 31;
                                        if (((nextop >> 3) & 7) == 4) {
                                            LDxw(x4, wback, 0);           // read only, no atomic needed
                                            BEXTI(x7, x4, u8);            // old bit
                                            ANDI(xFlags, xFlags, ~1);
                                            OR(xFlags, xFlags, x7);       // CF = old bit
                                        } else {
                                            ADDI(x2, wback, u8 >> 3);
                                            ANDI(x4, x2, 0b11);
                                            SLLI(x4, x4, 3);
                                            ORI(x4, x4, u8 & 7);
                                            ANDI(x2, x2, ~0b11);
                                            ADDI(x5, xZR, 1);
                                            SLL(x5, x5, x4);
                                            if (((nextop >> 3) & 7) == 5) {
                                                AMOOR_W(x6, x5, x2, 1, 1);
                                            } else if (((nextop >> 3) & 7) == 6) {
                                                XORI(x5, x5, -1);
                                                AMOAND_W(x6, x5, x2, 1, 1);
                                            } else {
                                                AMOXOR_W(x6, x5, x2, 1, 1);
                                            }
                                            SRL(x6, x6, x4);
                                            ANDI(x6, x6, 1);
                                            ANDI(xFlags, xFlags, ~1);
                                            OR(xFlags, xFlags, x6);
                                        }
                                    }
                                    break;
                                default:
                                    DEFAULT;
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;
                case 0xC0:
                    switch (rex.rep) {
                        case 0:
                            nextop = F8;
                            if (MODREG) {
                                INST_NAME("Invalid LOCK");
                                UDF();
                                *need_epilog = 1;
                                *ok = 0;
                            } else {
                                INST_NAME("LOCK XADD Gb, Eb");
                                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                                GETGB(x1);
                                addr = geted(dyn, addr, ninst, nextop, &wback, x5, x6, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                ANDI(x2, wback, 3);
                                SLLI(x2, x2, 3);        // bit shift
                                ANDI(x3, wback, ~3);    // aligned word
                                MARKLOCK;
                                LR_W(x4, x3, 1, 1);
                                SRL(x7, x4, x2);
                                ANDI(x7, x7, 0xFF);     // x7 = old byte
                                ADD(x6, x7, x1);        // old + gb
                                ANDI(x6, x6, 0xFF);     // new byte, 8 bits
                                SLL(x5, x7, x2);
                                SUB(x4, x4, x5);        // remove old byte
                                SLL(x5, x6, x2);
                                ADD(x4, x4, x5);        // insert new byte
                                SC_W(x5, x4, x3, 1, 1);
                                BNEZ_MARKLOCK(x5);
                                MV(x6, x7);             // save committed old byte
                                IFXORNAT (X_ALL | X_PEND) {
                                    emit_add8(dyn, ninst, x7, x1, x2, x5, x3);
                                }
                                MV(x1, x6);
                                GBBACK(x2);
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;
                case 0xC1:
                    switch (rex.rep) {
                        case 0:
                            nextop = F8;
                            if (MODREG) {
                                INST_NAME("Invalid LOCK");
                                UDF();
                                *need_epilog = 1;
                                *ok = 0;
                            } else {
                                INST_NAME("LOCK XADD Gd, Ed");
                                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                                GETGD;
                                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                AMOADDxw(x1, gd, wback, 1, 1);
                                IFXORNAT (X_ALL | X_PEND) {
                                    MVxw(x2, x1);
                                    emit_add32(dyn, ninst, rex, x2, gd, x3, x4, x5);
                                }
                                MVxw(gd, x1);
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;

                case 0xC7:
                    switch (rex.rep) {
                        case 0:
                            switch (rex.w) {
                                case 0:
                                    INST_NAME("LOCK CMPXCHG8B Gq, Eq");
                                    SETFLAGS(X_ZF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                                    SET_DFNONE();
                                    MARKREGd(xRAX);
                                    MARKREGd(xRDX);
                                    nextop = F8;
                                    addr = geted(dyn, addr, ninst, nextop, &wback, x1, x2, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                    ANDI(xFlags, xFlags, ~(1 << F_ZF));
                                    ZEXTW2(x3, xRAX);
                                    SLLI(x2, xRDX, 32);
                                    OR(x3, x3, x2); // x3 is edx:eax
                                    ZEXTW2(x4, xRBX);
                                    SLLI(x2, xRCX, 32);
                                    OR(x4, x4, x2); // x4 is ecx:ebx
                                    ANDI(x5, wback, 7);
                                    BNEZ_MARK3(x5);
                                    // Aligned
                                    MARKLOCK;
                                    LR_D(x2, wback, 1, 1);
                                    BNE_MARK(x2, x3);          // edx:eax != ed, load m64 into edx:eax
                                    SC_D(x5, x4, wback, 1, 1); // set ZF and load ecx:ebx into m64
                                    BNEZ_MARKLOCK(x5);
                                    ORI(xFlags, xFlags, 1 << F_ZF);
                                    B_NEXT_nocond;
                                    MARK;
                                    SRLI(xRDX, x2, 32);
                                    ZEXTW2(xRAX, x2);
                                    B_NEXT_nocond;
                                    MARK3;
                                    // Unaligned
                                    ANDI(x5, wback, -8);
                                    MARKLOCK2;
                                    LD(x2, wback, 0);
                                    LR_D(x6, x5, 1, 1);
                                    BNE_MARK2(x2, x3); // edx:eax != ed, load m64 into edx:eax
                                    SC_D(x7, x6, x5, 1, 1);
                                    BNEZ_MARKLOCK2(x7);
                                    SD(x4, wback, 0); // set ZF and load ecx:ebx into m64
                                    ORI(xFlags, xFlags, 1 << F_ZF);
                                    B_NEXT_nocond;
                                    MARK2;
                                    SRLI(xRDX, x2, 32);
                                    ZEXTW2(xRAX, x2);
                                    break;
                                case 1:
                                    INST_NAME("LOCK CMPXCHG16B Gq, Eq");
                                    MARKREGsd(xRAX);
                                    MARKREGsd(xRDX);
                                    MARKREGs(xRBX);
                                    MARKREGs(xRCX);
                                    static int warned = 0;
                                    PASS3(if (!warned) dynarec_log(LOG_INFO, "Warning, LOCK CMPXCHG16B is not well supported on RISC-V and issues are expected.\n"));
                                    PASS3(warned = 1);
                                    SETFLAGS(X_ZF, SF_SUBSET, NAT_FLAGS_NOFUSION);
                                    SET_DFNONE();
                                    nextop = F8;
                                    addr = geted(dyn, addr, ninst, nextop, &wback, x1, x2, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                                    ANDI(xFlags, xFlags, ~(1 << F_ZF));
                                    // there is no atomic move on 16bytes, so implement it with mutex
                                    LD(x7, xEmu, offsetof(x64emu_t, context));
                                    MOV32w(x3, offsetof(box64context_t, mutex_16b));
                                    ADD(x7, x7, x3);
                                    ADDI(x4, xZR, 1);
                                    MARK2;
                                    AMOSWAP_W(x4, x4, x7, 1, 1);
                                    // x4 == 1 if locked
                                    BNEZ_MARK2(x4);

                                    MARKLOCK;
                                    LD(x3, wback, 8);
                                    LR_D(x2, wback, 1, 1);
                                    BNE_MARK(x2, xRAX);
                                    BNE_MARK(x3, xRDX);
                                    SC_D(x5, xRBX, wback, 1, 1);
                                    BNEZ_MARKLOCK(x5);
                                    SD(xRCX, wback, 8);
                                    ORI(xFlags, xFlags, 1 << F_ZF);
                                    B_MARK3_nocond;
                                    MARK;
                                    MV(xRAX, x2);
                                    MV(xRDX, x3);
                                    MARK3;

                                    // unlock
                                    AMOSWAP_W(xZR, xZR, x7, 1, 1);
                                    break;
                            }
                            break;
                        default:
                            DEFAULT;
                    }
                    break;

                default:
                    DEFAULT;
            }
            break;
        case 0x10:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK ADC Eb, Gb");
                READFLAGS(X_CF);
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x2);
                addr = geted(dyn, addr, ninst, nextop, &wback, x1, x3, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x3, wback, 0b11);
                BNEZ_MARK(x3);
                MARKLOCK;
                LR_W(x5, wback, 1, 1);
                ANDI(x4, x5, 0xff);  // x4 = Ed.b[0]
                ANDI(x5, x5, ~0xff); // x5 = clear Ed.b[0]
                ADDW(x6, x4, x2);
                ANDI(x7, xFlags, 1 << F_CF);
                ADDW(x6, x6, x7); // x6 = adc
                ANDI(x6, x6, 0xff);
                OR(x5, x5, x6);
                SC_W(x7, x5, wback, 1, 1);
                BNEZ_MARKLOCK(x7);
                B_MARK3_nocond;
                MARK;
                SLLI(x3, x3, 3);
                ANDI(x1, wback, ~3); // aligning address (into scratch, wback may be a live guest reg)
                SLL(x2, x2, x3);     // x2 = extented Gb
                MARK2;
                ADDI(x4, xZR, 0xff); // x4 = byte mask (recomputed on SC retry: x4/x5 are clobbered in the loop)
                SLL(x4, x4, x3);
                NOT(x5, x4);         // x5 = ~mask
                LR_W(x6, x1, 1, 1); // x6 = Ed
                AND(x7, x6, x4);    // x7 = extended Ed.b[dest]
                AND(x6, x6, x5);    // x6 = clear Ed.b[dest]
                ADDW(x5, x7, x2);
                ANDI(x4, xFlags, 1 << F_CF);
                SLL(x4, x4, x3);  // extented
                ADDW(x5, x5, x4); // x5 = adc
                ADDI(x4, xZR, 0xff);
                SLL(x4, x4, x3);
                AND(x5, x5, x4);
                OR(x5, x5, x6);
                SC_W(x4, x5, x1, 1, 1);
                BNEZ_MARK2(x4);
                IFXORNAT (X_ALL | X_PEND) {
                    SRL(x2, x2, x3); // Gb
                    SRL(x4, x7, x3); // Eb
                }
                MARK3;
                IFXORNAT (X_ALL | X_PEND) {
                    emit_adc8(dyn, ninst, x4, x2, x3, x5, x6);
                }
            }
            break;
        case 0x11:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK ADC Ed, Gd");
                READFLAGS(X_CF);
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                MARKLOCK;
                LRxw(x1, wback, 1, 1);
                ADDxw(x3, x1, gd);
                ANDI(x4, xFlags, 1 << F_CF);
                ADDxw(x3, x3, x4);
                SCxw(x4, x3, wback, 1, 1);
                BNEZ_MARKLOCK(x4);
                IFXORNAT (X_ALL | X_PEND) {
                    emit_adc32(dyn, ninst, rex, x1, gd, x3, x4, x5, x6);
                }
            }
            break;
        case 0x19:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK SBB Ed, Gd");
                READFLAGS(X_CF);
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                MARKLOCK;
                LRxw(x1, wback, 1, 1);
                SUBxw(x3, x1, gd);
                ANDI(x4, xFlags, 1 << F_CF);
                SUBxw(x3, x3, x4);
                SCxw(x4, x3, wback, 1, 1);
                BNEZ_MARKLOCK(x4);
                IFXORNAT (X_ALL | X_PEND)
                    emit_sbb32(dyn, ninst, rex, x1, gd, x3, x4, x5);
            }
            break;
        case 0x20:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK AND Eb, Gb");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x1);
                addr = geted(dyn, addr, ninst, nextop, &wback, x5, x6, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x2, wback, 3);
                SLLI(x2, x2, 3);
                ANDI(x3, wback, ~3);
                XORI(x6, x1, 0xFF);
                SLL(x6, x6, x2);
                NOT(x6, x6);
                AMOAND_W(x4, x6, x3, 1, 1);
                IFXORNAT (X_ALL | X_PEND) {
                    SRL(x2, x4, x2);
                    ANDI(x2, x2, 0xFF);
                    emit_and8(dyn, ninst, x2, x1, x4, x5);
                }
            }
            break;
        case 0x21:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK AND Ed, Gd");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                AMOANDxw(x1, gd, wback, 1, 1);
                IFXORNAT (X_ALL | X_PEND)
                    emit_and32(dyn, ninst, rex, x1, gd, x3, x4);
            }
            break;
        case 0x28:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK SUB Eb, Gb");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGB(x1);
                addr = geted(dyn, addr, ninst, nextop, &wback, x6, x7, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x2, wback, 3);
                SLLI(x2, x2, 3);
                ANDI(x3, wback, ~3);
                MARKLOCK;
                LR_W(x4, x3, 1, 1);
                SRL(x5, x4, x2);
                ANDI(x5, x5, 0xFF); // old byte
                SUB(x7, x5, x1);
                ANDI(x7, x7, 0xFF); // new byte
                SLL(x6, x5, x2);
                SUB(x4, x4, x6);
                SLL(x6, x7, x2);
                ADD(x4, x4, x6);
                SC_W(x6, x4, x3, 1, 1);
                BNEZ_MARKLOCK(x6);
                IFXORNAT (X_ALL | X_PEND) {
                    emit_sub8(dyn, ninst, x5, x1, x2, x3, x4);
                }
            }
            break;
        case 0x29:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK SUB Ed, Gd");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                SUBxw(x4, xZR, gd);
                AMOADDxw(x1, x4, wback, 1, 1);
                IFXORNAT (X_ALL | X_PEND)
                    emit_sub32(dyn, ninst, rex, x1, gd, x3, x4, x5);
            }
            break;
        case 0x31:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK XOR Ed, Gd");
                SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                GETGD;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                AMOXORxw(x1, gd, wback, 1, 1);
                IFXORNAT (X_ALL | X_PEND)
                    emit_xor32(dyn, ninst, rex, x1, gd, x3, x4);
            }
            break;
        case 0x80:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 1: // OR
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK OR Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        ADDI(x1, xZR, u8);
                        SLL(x1, x1, x2); // Ib << offset
                        AMOOR_W(x4, x1, x3, 1, 1);
                        IFXORNAT (X_ALL | X_PEND) {
                            SRL(x1, x4, x2);
                            ANDI(x1, x1, 0xFF);
                            emit_or8c(dyn, ninst, x1, u8, x2, x4, x5);
                        }
                    }
                    break;
                case 2: // ADC
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK ADC Eb, Ib");
                        READFLAGS(X_CF);
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);             // offset in bits
                        ANDI(x3, wback, ~3);         // aligned addr
                        MARKLOCK;
                        ANDI(x7, xFlags, 1 << F_CF); // carry-in (recomputed on SC retry: x7 is clobbered in the loop)
                        ADDI(x7, x7, u8);            // imm + carry
                        LR_W(x4, x3, 1, 1);
                        SRL(x6, x4, x2);
                        ANDI(x6, x6, 0xFF);          // x6 = old byte
                        ADD(x1, x6, x7);             // old + imm + carry
                        ANDI(x1, x1, 0xFF);          // new byte
                        SLL(x7, x6, x2);
                        SUB(x4, x4, x7);             // remove old byte
                        SLL(x7, x1, x2);
                        ADD(x4, x4, x7);             // insert new byte
                        SC_W(x5, x4, x3, 1, 1);
                        BNEZ_MARKLOCK(x5);
                        IFXORNAT (X_ALL | X_PEND) {
                            emit_adc8c(dyn, ninst, x6, u8, x2, x3, x4, x5);
                        }
                    }
                    break;
                case 0: // ADD
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK ADD Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        MARKLOCK;
                        LR_W(x4, x3, 1, 1);
                        SRL(x1, x4, x2);
                        ANDI(x1, x1, 0xFF);  // old byte
                        ADDI(x6, x1, u8);    // old + imm
                        ANDI(x6, x6, 0xFF);  // new byte
                        SLL(x7, x1, x2);
                        SUB(x4, x4, x7);     // remove old byte
                        SLL(x7, x6, x2);
                        ADD(x4, x4, x7);     // insert new byte
                        SC_W(x5, x4, x3, 1, 1);
                        BNEZ_MARKLOCK(x5);
                        IFXORNAT (X_ALL | X_PEND) {
                            emit_add8c(dyn, ninst, x1, u8, x2, x3, x4, x5);
                        }
                    }
                    break;
                case 3: // SBB
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK SBB Eb, Ib");
                        READFLAGS(X_CF);
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        MARKLOCK;
                        ANDI(x7, xFlags, 1 << F_CF); // borrow-in (recomputed on SC retry: x7 is clobbered in the loop)
                        ADDI(x7, x7, u8);            // imm + borrow
                        LR_W(x4, x3, 1, 1);
                        SRL(x6, x4, x2);
                        ANDI(x6, x6, 0xFF);          // x6 = old byte
                        SUB(x1, x6, x7);             // old - imm - borrow
                        ANDI(x1, x1, 0xFF);          // new byte
                        SLL(x7, x6, x2);
                        SUB(x4, x4, x7);             // remove old byte
                        SLL(x7, x1, x2);
                        ADD(x4, x4, x7);             // insert new byte
                        SC_W(x5, x4, x3, 1, 1);
                        BNEZ_MARKLOCK(x5);
                        IFXORNAT (X_ALL | X_PEND) {
                            emit_sbb8c(dyn, ninst, x6, u8, x2, x3, x4, x5);
                        }
                    }
                    break;
                case 5: // SUB
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK SUB Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        MARKLOCK;
                        LR_W(x4, x3, 1, 1);
                        SRL(x1, x4, x2);
                        ANDI(x1, x1, 0xFF);  // old byte
                        ADDI(x6, x1, -u8);   // old - imm
                        ANDI(x6, x6, 0xFF);  // new byte
                        SLL(x7, x1, x2);
                        SUB(x4, x4, x7);
                        SLL(x7, x6, x2);
                        ADD(x4, x4, x7);
                        SC_W(x5, x4, x3, 1, 1);
                        BNEZ_MARKLOCK(x5);
                        IFXORNAT (X_ALL | X_PEND) {
                            emit_sub8c(dyn, ninst, x1, u8, x2, x3, x4, x5);
                        }
                    }
                    break;
                case 6: // XOR
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK XOR Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        ADDI(x1, xZR, u8);
                        SLL(x1, x1, x2);     // Ib << offset
                        AMOXOR_W(x4, x1, x3, 1, 1);
                        IFXORNAT (X_ALL | X_PEND) {
                            SRL(x1, x4, x2);
                            ANDI(x1, x1, 0xFF);
                            emit_xor8c(dyn, ninst, x1, u8, x4, x5);
                        }
                    }
                    break;
                case 7: // CMP
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK CMP Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        LB(x1, wback, 0);
                        ANDI(x1, x1, 0xFF);  // old byte
                        emit_test8c(dyn, ninst, x1, u8, x2, x3, x4);
                    }
                    break;
                case 4: // AND
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK AND Eb, Ib");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x5, x1, &fixedaddress, rex, LOCK_LOCK, 0, 1);
                        u8 = F8;
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);     // offset in bits
                        ANDI(x3, wback, ~3); // aligned addr
                        ADDI(x1, xZR, u8);
                        XORI(x1, x1, 0xFF);
                        SLL(x1, x1, x2); // (0xFF ^ Ib) << offset
                        NOT(x1, x1);     // mask: Ib in target byte, 0xFF elsewhere
                        AMOAND_W(x4, x1, x3, 1, 1);
                        IFXORNAT (X_ALL | X_PEND) {
                            SRL(x1, x4, x2);
                            ANDI(x1, x1, 0xFF);
                            emit_and8c(dyn, ninst, x1, u8, x4, x5);
                        }
                    }
                    break;
                default:
                    DEFAULT;
            }
            break;
        case 0x81:
        case 0x83:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 0: // ADD
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK ADD Ed, Id");
                        } else {
                            INST_NAME("LOCK ADD Ed, Ib");
                        }
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        MOV64xw(x7, i64);
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        AMOADDxw(x1, x7, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        ADDxw(x4, x1, x7);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND)
                            emit_add32c(dyn, ninst, rex, x1, i64, x3, x4, x5, x6);
                    }
                    break;
                case 1: // OR
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK OR Ed, Id");
                        } else {
                            INST_NAME("LOCK OR Ed, Ib");
                        }
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        MOV64xw(x4, i64);
                        AMOORxw(x1, x4, wback, 1, 1);
                        IFXORNAT (X_ALL | X_PEND)
                            emit_or32c(dyn, ninst, rex, x1, i64, x3, x4);
                    }
                    break;
                case 2: // ADC
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK ADC Ed, Id");
                        } else {
                            INST_NAME("LOCK ADC Ed, Ib");
                        }
                        READFLAGS(X_CF);
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        ANDI(x6, xFlags, 1 << F_CF); // carry-in, read once
                        MOV64xw(x7, i64);
                        ADD(x7, x7, x6);             // imm + carry
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        AMOADDxw(x1, x7, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        ADDxw(x4, x1, x7);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND) {
                            MOV64xw(x5, i64);        // raw imm, for the flags
                            emit_adc32(dyn, ninst, rex, x1, x5, x3, x4, x6, x2);
                        }
                    }
                    break;
                case 3: // SBB
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK SBB Ed, Id");
                        } else {
                            INST_NAME("LOCK SBB Ed, Ib");
                        }
                        READFLAGS(X_CF);
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        ANDI(x6, xFlags, 1 << F_CF); // borrow-in, read once
                        MOV64xw(x7, i64);
                        ADD(x7, x7, x6);             // imm + borrow
                        SUBxw(x7, xZR, x7);          // negate: mem -= (imm + borrow)
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        AMOADDxw(x1, x7, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        ADDxw(x4, x1, x7);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND) {
                            MV(x6, x1);              // old value
                            MOV64xw(x5, i64);        // raw imm, for the flags
                            MV(x1, x6);
                            emit_sbb32(dyn, ninst, rex, x1, x5, x3, x4, x6);
                        }
                    }
                    break;
                case 4: // AND
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK AND Ed, Id");
                        } else {
                            INST_NAME("LOCK AND Ed, Ib");
                        }
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        MOV64xw(x7, i64);
                        AMOANDxw(x1, x7, wback, 1, 1);
                        IFXORNAT (X_ALL | X_PEND)
                            emit_and32c(dyn, ninst, rex, x1, i64, x3, x4);
                    }
                    break;
                case 5: // SUB
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK SUB Ed, Id");
                        } else {
                            INST_NAME("LOCK SUB Ed, Ib");
                        }
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        MOV64xw(x7, i64);
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        SUBxw(x4, xZR, x7);
                        AMOADDxw(x1, x4, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        SUBxw(x4, x1, x7);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND)
                            emit_sub32c(dyn, ninst, rex, x1, i64, x3, x4, x5, x6);
                    }
                    break;
                case 6: // XOR
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (opcode == 0x81) {
                            INST_NAME("LOCK XOR Ed, Id");
                        } else {
                            INST_NAME("LOCK XOR Ed, Ib");
                        }
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, (opcode == 0x81) ? 4 : 1);
                        if (opcode == 0x81)
                            i64 = F32S;
                        else
                            i64 = F8S;
                        MOV64xw(x7, i64);
                        AMOXORxw(x1, x7, wback, 1, 1);
                        IFXORNAT (X_ALL | X_PEND)
                            emit_xor32c(dyn, ninst, rex, x1, i64, x3, x4);
                    }
                    break;
                default: DEFAULT;
            }
            break;
        case 0x87:
            nextop = F8;
            if (MODREG) {
                INST_NAME("Invalid LOCK");
                UDF();
                *need_epilog = 1;
                *ok = 0;
            } else {
                INST_NAME("LOCK XCHG Ed, Gd");
                GETGDsd;
                addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                BNEZ_MARK3(x1);
                // Aligned
                AMOSWAPxw(gd, gd, wback, 1, 1);
                if (!rex.w) ZEROUP(gd);
                B_NEXT_nocond;
                MARK3;
                // Unaligned
                ANDI(x5, wback, -(1 << (rex.w + 2)));
                MARKLOCK;
                LDxw(x1, wback, 0);
                LRxw(x3, x5, 1, 1);
                SCxw(x4, x3, x5, 1, 1);
                BNEZ_MARKLOCK(x4);
                SDxw(gd, wback, 0);
                MVxw(gd, x1);
            }
            break;
        case 0xF6:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 2:
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK NOT Eb");
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ANDI(x3, wback, 3);
                        ANDI(x5, wback, ~3);
                        MOV32w(x4, 0xFF);
                        SLLIW(x3, x3, 3);
                        SLLW(x4, x4, x3); // mask
                        AMOXOR_W(xZR, x4, x5, 1, 1);
                    }
                    break;
                case 3: // NEG
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK NEG Eb");
                        SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ANDI(x5, wback, ~3);
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);
                        MARKLOCK;
                        LR_W(x6, x5, 1, 1);
                        SRL(x3, x6, x2);
                        ANDI(x3, x3, 0xFF);        // old byte
                        SUB(x1, xZR, x3);          // 0 - old
                        ANDI(x1, x1, 0xFF);        // new byte
                        SLL(x4, x3, x2);
                        SUB(x6, x6, x4);           // remove old byte
                        SLL(x4, x1, x2);
                        ADD(x6, x6, x4);           // insert new byte
                        SC_W(x4, x6, x5, 1, 1);
                        BNEZ_MARKLOCK(x4);
                        MV(x1, x3);                // old byte
                        IFXORNAT (X_ALL | X_PEND) {
                            emit_neg8(dyn, ninst, x1, x2, x3, x4);
                        }
                    }
                    break;
                default:
                    DEFAULT;
            }
            break;
        case 0xF7:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 2:
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK NOT Ed");
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ADDI(x4, xZR, -1);
                        AMOXORxw(xZR, x4, wback, 1, 1);
                    }
                    break;
                case 3: // NEG Ed
                    INST_NAME("LOCK NEG Ed");
                    SETFLAGS(X_ALL, SF_SET_PENDING, NAT_FLAGS_FUSION);
                    addr = geted(dyn, addr, ninst, nextop, &wback, x5, x6, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                    ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                    BNEZ_MARK3(x1); // not aligned
                    ANDI(x7, wback, -(1 << (rex.w + 2)));
                    MARKLOCK;
                    LRxw(x4, x7, 1, 1);
                    NEGxw(x1, x4);
                    SCxw(x6, x1, x7, 1, 1);
                    BNEZ_MARKLOCK(x6);
                    MV(x1, x4); // committed original value
                    emit_neg32(dyn, ninst, rex, x1, x2, x3, x4, x6);
                    B_NEXT_nocond;

                    MARK3;
                    // generic, unaligned
                    LDxw(x1, wback, 0);
                    emit_neg32(dyn, ninst, rex, x1, x2, x3, x4, x6);
                    SDxw(x1, wback, 0);
                    break;
                default:
                    DEFAULT;
            }
            break;
        case 0xFE:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 0:
                case 1:
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        if (((nextop >> 3) & 7) == 0)
                            INST_NAME("LOCK INC Eb");
                        else
                            INST_NAME("LOCK DEC Eb");
                        SETFLAGS(X_ALL & ~X_CF, SF_SUBSET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ANDI(x5, wback, ~3);
                        ANDI(x2, wback, 3);
                        SLLI(x2, x2, 3);
                        MARKLOCK2;
                        LR_W(x6, x5, 1, 1);
                        SRL(x3, x6, x2);
                        ANDI(x3, x3, 0xFF); // old byte
                        if (((nextop >> 3) & 7) == 0)
                            ADDI(x4, x3, 1);
                        else
                            ADDI(x4, x3, -1);
                        ANDI(x4, x4, 0xFF);
                        SLL(x7, x3, x2);
                        SUB(x6, x6, x7);
                        SLL(x7, x4, x2);
                        ADD(x6, x6, x7);
                        SC_W(x1, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x1);
                        IFXORNAT (X_ALL | X_PEND) {
                            if (((nextop >> 3) & 7) == 0)
                                emit_inc8(dyn, ninst, x3, x4, x5, x6);
                            else
                                emit_dec8(dyn, ninst, x3, x4, x5, x6);
                        }
                    }
                    break;
                default:
                    DEFAULT;
            }
            break;
        case 0xFF:
            nextop = F8;
            switch ((nextop >> 3) & 7) {
                case 0: // INC Ed
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK INC Ed");
                        SETFLAGS(X_ALL & ~X_CF, SF_SUBSET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        ADDIxw(x4, xZR, 1);
                        AMOADDxw(x1, x4, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        ADDIxw(x4, x1, 1);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND)
                            emit_inc32(dyn, ninst, rex, x1, x3, x4, x5, x6);
                    }
                    break;
                case 1: // DEC Ed
                    if (MODREG) {
                        INST_NAME("Invalid LOCK");
                        UDF();
                        *need_epilog = 1;
                        *ok = 0;
                    } else {
                        INST_NAME("LOCK DEC Ed");
                        SETFLAGS(X_ALL & ~X_CF, SF_SUBSET_PENDING, NAT_FLAGS_FUSION);
                        addr = geted(dyn, addr, ninst, nextop, &wback, x2, x1, &fixedaddress, rex, LOCK_LOCK, 0, 0);
                        ANDI(x1, wback, (1 << (rex.w + 2)) - 1);
                        BNEZ_MARK3(x1);
                        // Aligned
                        ADDIxw(x4, xZR, -1);
                        AMOADDxw(x1, x4, wback, 1, 1);
                        B_MARK_nocond;
                        MARK3;
                        // Unaligned
                        ANDI(x5, wback, -(1 << (rex.w + 2)));
                        MARKLOCK2;
                        LDxw(x1, wback, 0);
                        LRxw(x6, x5, 1, 1);
                        ADDIxw(x4, x1, -1);
                        SCxw(x3, x6, x5, 1, 1);
                        BNEZ_MARKLOCK2(x3);
                        SDxw(x4, wback, 0);
                        MARK;
                        IFXORNAT (X_ALL | X_PEND)
                            emit_dec32(dyn, ninst, rex, x1, x3, x4, x5, x6);
                    }
                    break;
                default:
                    DEFAULT;
            }
            break;
        default:
            DEFAULT;
    }
    return addr;
}
