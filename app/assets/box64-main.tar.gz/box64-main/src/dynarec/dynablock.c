// SPDX-License-Identifier: MIT
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>

#include "os.h"
#include "debug.h"
#include "box64context.h"
#include "box64cpu.h"
#include "emu/x64emu_private.h"
#include "x64emu.h"
#include "box64stack.h"
#include "callback.h"
#include "emu/x64run_private.h"
#include "x64trace.h"
#include "dynablock.h"
#include "dynablock_private.h"
#include "dynarec_private.h"
#include "alternate.h"

#include "dynarec_native.h"
#include "dynarec_arch.h"
#include "native_lock.h"
#ifdef BOX64EC
#include "box64ec.h"
#endif

#include "custommem.h"
#include "khash.h"
#include "rbtree.h"

// ---- fast hash for block change detection ----
static uint32_t normal_fast_hash(void* p, uint32_t len)
{
    const uint8_t* data = (const uint8_t*)p;
    uint64_t h = len * UINT64_C(0x9E3779B97F4A7C15);

    while (len >= 8) {
        uint64_t k;
        __builtin_memcpy(&k, data, 8);
        k *= UINT64_C(0xBF58476D1CE4E5B9);
        k ^= k >> 31;
        h ^= k;
        h *= UINT64_C(0x94D049BB133111EB);
        data += 8;
        len -= 8;
    }

    if (len) {
        uint64_t k = 0;
        switch(len) {
            case 7: k |= (uint64_t)data[6] << 48; /* fall through */
            case 6: k |= (uint64_t)data[5] << 40; /* fall through */
            case 5: k |= (uint64_t)data[4] << 32; /* fall through */
            case 4: k |= (uint64_t)data[3] << 24; /* fall through */
            case 3: k |= (uint64_t)data[2] << 16; /* fall through */
            case 2: k |= (uint64_t)data[1] <<  8; /* fall through */
            case 1: k |= (uint64_t)data[0];
        }
        k *= UINT64_C(0xBF58476D1CE4E5B9);
        k ^= k >> 31;
        h ^= k;
        h *= UINT64_C(0x94D049BB133111EB);
    }

    h ^= h >> 33;
    h *= UINT64_C(0xFF51AFD7ED558CCD);
    h ^= h >> 33;

    return (uint32_t)h;
}

uint32_t X31_hash_code(void* addr, int len)
{
    if(!len) return 0;
    #ifdef ARCH_CRC
    ARCH_CRC(addr, len);
    #endif
    return normal_fast_hash(addr, (uint32_t)len);
}

dynablock_t* InvalidDynablock(dynablock_t* db, int need_lock)
{
    if(db) {
        if(db->gone)
            return NULL; // already in the process of deletion!
        dynarec_log(LOG_DEBUG, "InvalidDynablock(%p), db->block=%p x64=%p:%p already gone=%d\n", db, db->block, db->x64_addr, db->x64_addr+db->x64_size-1, db->gone);
        // remove jumptable without waiting
        setJumpTableDefault64(db->x64_addr);
        if(need_lock)
            mutex_lock(&my_context->mutex_dyndump);
        db->done = 0;
        db->gone = 1;
        uintptr_t db_size = db->x64_size;
        #ifdef ARCH_NOP
        if(db->callret_size) {
            // mark all callrets to UDF
            for(int i=0; i<db->callret_size; ++i)
                *(uint32_t*)(db->block+db->callrets[i].offs) = ARCH_UDF;
            ClearCache(db->block, db->size);
        }
        #endif
        if(db_size && my_context && !BOX64ENV(dynarec_dirty)) {
            uint32_t n = rb_dec(my_context->db_sizes, db_size, db_size+1);
            if(!n && (db_size >= my_context->max_db_size)) {
                my_context->max_db_size = rb_get_rightmost(my_context->db_sizes);
                dynarec_log(LOG_INFO, "BOX64 Dynarec: lower max_db=%d\n", my_context->max_db_size);
            }
        }
        if(need_lock)
            mutex_unlock(&my_context->mutex_dyndump);
    }
    return db;
}

static void QueueZombieDynablock(dynablock_t* db);

static void RetireOrphanDynablocks(void)
{
    for (int i = 0; i < my_context->db_orphan_count; ) {
        dynablock_t* db = my_context->db_orphan[i];
        if (db && native_lock_get_d(&db->in_used) > 0) {
            ++i;
            continue;
        }
        my_context->db_orphan[i] = my_context->db_orphan[--my_context->db_orphan_count];
        // released by its last user: requeue it instead of freeing right away, a thread
        // may still be running the last instructions of the block (and the enter/leave
        // pair is not atomic with the code around it)
        if (db) QueueZombieDynablock(db);
    }
}

static void QueueOrphanDynablock(dynablock_t* db)
{
    if (my_context->db_orphan_count == my_context->db_orphan_size) {
        int nsize = my_context->db_orphan_size ? my_context->db_orphan_size * 2 : 64;
        dynablock_t** nlist = box_malloc(nsize * sizeof(dynablock_t*));
        if (!nlist) return;
        if (my_context->db_orphan_count)
            memcpy(nlist, my_context->db_orphan, my_context->db_orphan_count * sizeof(dynablock_t*));
        if (my_context->db_orphan) box_free(my_context->db_orphan);
        my_context->db_orphan = nlist;
        my_context->db_orphan_size = nsize;
    }
    my_context->db_orphan[my_context->db_orphan_count++] = db;
}

static void QueueZombieDynablock(dynablock_t* db)
{
    // enq for a deferred free so any threads still running in this block has a better chance to finish.
    if (my_context->db_zombie_count == DB_ZOMBIE_SIZE) {
        // Queue full: free the oldest queued block that no running dynarec chain holds (in_used), compact the queue.
        int idx = -1;        // queue position of the entry to drop, 0 = oldest
        int idx_in_used = 0; // in_used count of that entry
        for (int i = 0; i < DB_ZOMBIE_SIZE; ++i) {
            int slot = (my_context->db_zombie_head - DB_ZOMBIE_SIZE + i + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
            dynablock_t* z = my_context->db_zombie[slot];
            if (!z)
                continue;
            int cnt = native_lock_get_d(&z->in_used);
            if (cnt <= 0) {
                idx = i;
                idx_in_used = cnt;
                break;
            }
            if (idx < 0) {
                idx = i;    // remember the oldest held block, in case all of them are held
                idx_in_used = cnt;
            }
        }
        if (idx < 0)
            idx = 0;    // queue is full of empty slots: just drop the oldest one
        // free the picked entry
        int slot = (my_context->db_zombie_head - DB_ZOMBIE_SIZE + idx + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
        if (idx_in_used > 0) {
            printf_log(LOG_DEBUG, "Warning, all %d queued dynablocks are still in use, deferring the oldest one (in_used=%d)\n", DB_ZOMBIE_SIZE, idx_in_used);
            QueueOrphanDynablock(my_context->db_zombie[slot]);
        } else if (my_context->db_zombie[slot])
            FreeDynarecMap((uintptr_t)my_context->db_zombie[slot]->actual_block);
        // shift all newer entries over the dropped one, then queue db at the tail
        for (int i = idx; i < DB_ZOMBIE_SIZE - 1; ++i) {
            int cur = (my_context->db_zombie_head - DB_ZOMBIE_SIZE + i + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
            int nxt = (my_context->db_zombie_head - DB_ZOMBIE_SIZE + i + 1 + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
            my_context->db_zombie[cur] = my_context->db_zombie[nxt];
        }
        my_context->db_zombie[(my_context->db_zombie_head - 1 + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE] = db;
    } else {
        my_context->db_zombie[my_context->db_zombie_head] = db;
        my_context->db_zombie_head = (my_context->db_zombie_head + 1) % DB_ZOMBIE_SIZE;
        my_context->db_zombie_count++;
    }
}

static void DeferFreeDynablockMap(dynablock_t* db)
{
    if (my_context->db_orphan_count) RetireOrphanDynablocks();
    QueueZombieDynablock(db);
}

void DeferFreeDynablockClearRange(void* addr, size_t sz)
{
    int head = my_context->db_zombie_head;
    for(int i=0; i<my_context->db_zombie_count; ++i) {
        int idx = (head - my_context->db_zombie_count + i + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
        if(my_context->db_zombie[idx] && ((void*)my_context->db_zombie[idx]>=addr) && ((void*)my_context->db_zombie[idx]<(addr+sz)))
            my_context->db_zombie[idx] = NULL;
    }
    for(int i=0; i<my_context->db_orphan_count; )
        if(my_context->db_orphan[i] && ((void*)my_context->db_orphan[i]>=addr) && ((void*)my_context->db_orphan[i]<(addr+sz)))
            my_context->db_orphan[i] = my_context->db_orphan[--my_context->db_orphan_count];
        else
            ++i;
}

void FreeInvalidDynablock(dynablock_t* db, int need_lock)
{
    if(db) {
        if(!db->gone)
            return; // already in the process of deletion!
        dynarec_log(LOG_DEBUG, "FreeInvalidDynablock(%p), db->block=%p x64=%p:%p\n", db, db->block, db->x64_addr, db->x64_addr + db->x64_size - 1);
        uintptr_t db_size = db->x64_size;
        if(need_lock)
            mutex_lock(&my_context->mutex_dyndump);
        // need_lock is also used to check if db_size needs to be decremented...
        if(need_lock && db_size && my_context && BOX64ENV(dynarec_dirty)) {
            uint32_t n = rb_dec(my_context->db_sizes, db_size, db_size+1);
            if(!n && (db_size >= my_context->max_db_size)) {
                my_context->max_db_size = rb_get_rightmost(my_context->db_sizes);
                dynarec_log(LOG_INFO, "BOX64 Dynarec: lower max_db=%d\n", my_context->max_db_size);
            }
        }
        DeferFreeDynablockMap(db);
        if(need_lock)
            mutex_unlock(&my_context->mutex_dyndump);
    }
}

void FreeDynablock(dynablock_t* db, int need_lock, int need_remove)
{
    if(db) {
        if(db->gone)
            return; // already in the process of deletion!
        dynarec_log(LOG_DEBUG, "FreeDynablock(%p), db->block=%p x64=%p:%p already gone=%d\n", db, db->block, db->x64_addr, db->x64_addr+db->x64_size-1, db->gone);
        // remove jumptable without waiting
        if(need_remove) {
            setJumpTableDefault64(db->x64_addr);
        }
        if(need_lock)
            mutex_lock(&my_context->mutex_dyndump);
        dynarec_log(LOG_DEBUG, " -- FreeDyrecMap(%p, %d)\n", db->actual_block, db->size);
        db->done = 0;
        db->gone = 1;
        uintptr_t db_size = db->x64_size;
        if(db_size && my_context) {
            uint32_t n = rb_dec(my_context->db_sizes, db_size, db_size+1);
            if(!n && (db_size >= my_context->max_db_size)) {
                my_context->max_db_size = rb_get_rightmost(my_context->db_sizes);
                dynarec_log(LOG_INFO, "BOX64 Dynarec: lower max_db=%d\n", my_context->max_db_size);
            }
        }
        DeferFreeDynablockMap(db);
        if(need_lock)
            mutex_unlock(&my_context->mutex_dyndump);
    }
}

void MarkDynablock(dynablock_t* db)
{
    if(db) {
        dynarec_log(LOG_DEBUG, "MarkDynablock %p %p-%p\n", db, db->x64_addr, db->x64_addr+db->x64_size-1);
        if(!setJumpTableIfRef64(db->x64_addr, db->jmpnext, db->block)) {
            dynablock_t* old = db;
            db = getDB((uintptr_t)old->x64_addr);
            if(!old->gone && db!=old) {
                printf_log(LOG_INFO, "Warning, couldn't mark block as dirty for %p, block=%p, current_block=%p\n", old->x64_addr, old, db);
                // the block is lost, need to invalidate and defer its free
                old->gone = 1;
                old->done = 0;
                FreeInvalidDynablock(old, 1);
            }
        #ifdef ARCH_NOP
        } else {
            if(db->callret_size) {
                // mark all callrets to UDF
                for(int i=0; i<db->callret_size; ++i)
                    *(uint32_t*)(db->block+db->callrets[i].offs) = ARCH_UDF;
                ClearCache(db->block, db->size);
            }
        #endif
        }
    }
}

static int IntervalIntersects(uintptr_t start1, uintptr_t end1, uintptr_t start2, uintptr_t end2)
{
    if(start1 > end2 || start2 > end1)
        return 0;
    return 1;
}

void MarkRangeDynablock(dynablock_t* db, uintptr_t addr, uintptr_t size)
{
    // Mark will try to find *any* blocks that intersect the range to mark
    if(!db)
        return;
    dynarec_log(LOG_DEBUG, "MarkRangeDynablock %p-%p .. startdb=%p, sizedb=%p\n", (void*)addr, (void*)addr+size-1, (void*)db->x64_addr, (void*)db->x64_size);
    if(IntervalIntersects((uintptr_t)db->x64_addr, (uintptr_t)db->x64_addr+db->x64_size-1, addr, addr+size+1))
        MarkDynablock(db);
}

void MarkCRCRangeDynablock(dynablock_t* db, uintptr_t addr, uintptr_t size)
{
    // Mark will try to find *any* blocks that intersect the range to mark
    if(!db)
        return;
    dynarec_log(LOG_DEBUG, "MarkCRCRangeDynablock %p-%p .. startdb=%p, sizedb=%p\n", (void*)addr, (void*)addr+size-1, (void*)db->x64_addr, (void*)db->x64_size);
    if(IntervalIntersects((uintptr_t)db->x64_addr, (uintptr_t)db->x64_addr+db->x64_size-1, addr, addr+size+1)) {
        MarkDynablock(db);  // mark as dirty
        db->to_delete = 1;  // also invalid hash, so it will be deleted and replace
    }
}

int FreeRangeDynablock(dynablock_t* db, uintptr_t addr, uintptr_t size)
{
    if(!db)
        return 1;

    int need_lock = my_context?1:0;
    if(IntervalIntersects((uintptr_t)db->x64_addr, (uintptr_t)db->x64_addr+db->x64_size-1, addr, addr+size+1)) {
        FreeDynablock(db, need_lock, 1);
        return 0;
    }
    return 1;
}

void dynablock_leave_runtime(dynablock_t* db)
{
    if(!db) return;
#ifdef HAVE_IN_USED
    if(BOX64ENV(dynarec_callret) < 3) return;
    __atomic_fetch_sub(&db->in_used, 1, __ATOMIC_ACQ_REL);
#endif
}

dynablock_t* CreateDBnoAlt(x64emu_t* emu, uintptr_t addr, int is32bits)
{
    #ifndef WIN32
    static int critical_filled = 0;
    static sigset_t critical_prot = {0};
    sigset_t old_sig = {0};
    if(!critical_filled) {
        critical_filled = 1;
        sigfillset(&critical_prot);
        sigdelset(&critical_prot, SIGSEGV);
        sigdelset(&critical_prot, SIGILL);
        sigdelset(&critical_prot, SIGBUS);
        sigdelset(&critical_prot, SIGINT);
        sigdelset(&critical_prot, SIGABRT);
        sigdelset(&critical_prot, SIGFPE);
    }
    #endif

    pthread_sigmask(SIG_BLOCK, &critical_prot, &old_sig);

    if(BOX64ENV(dynarec_wait)) {
        mutex_lock(&my_context->mutex_dyndump);
    } else {
        if(mutex_trylock(&my_context->mutex_dyndump)) {   // FillBlock not available for now
            pthread_sigmask(SIG_SETMASK, &old_sig, NULL);
            return NULL;
        }
    }

    dynarec_log(LOG_DEBUG, "Will call Fillblock64 for Alt %p\n", (void*)addr);
    dynablock_t* block = FillBlock64(addr, is32bits, MAX_INSTS, 0, 1);
    if(block && block->block) block->done = 1;  // validate the alt block

    mutex_unlock(&my_context->mutex_dyndump);

    pthread_sigmask(SIG_SETMASK, &old_sig, NULL);

    return block;
}

/* 
    return NULL if block is not found / cannot be created. 
    Don't create if create==0
*/
dynablock_t* internalDBGetBlock(x64emu_t* emu, uintptr_t addr, int create, int need_lock, int is32bits, int is_new, dynablock_t* block)
{
    const uint32_t req_prot = (box64_pagesize==4096)?(PROT_EXEC|PROT_READ):PROT_READ;
    #ifdef BOX64EC
    // never build a block from ARM64EC code, the JIT memory is ARM64EC code too
    if(Box64EC_IsEcCode(addr))
        return NULL;
    #endif
    if(BOX64ENV(nodynarec_delay) && (addr>=BOX64ENV(nodynarec_start)) && (addr<BOX64ENV(nodynarec_end)))
        return NULL;
    if(!block)
        block = getDB(addr);
    if(block==SEARCHED_NO_DYNABLOCK)
        block = NULL;
    if(block && block->to_delete) {
        // just delete the block then, so we can create a new one right away
        FreeDynablock(block, 1, 1);
        block = NULL;
    }
    if(block || !create) {
        if(block && getNeedTest(addr) && (getProtection(block->x64_readaddr)&req_prot)!=req_prot)
            block = NULL;
        return block;
    }

    #ifndef WIN32
    static int critical_filled = 0;
    static sigset_t critical_prot = {0};
    sigset_t old_sig = {0};
    if(!critical_filled) {
        critical_filled = 1;
        sigfillset(&critical_prot);
        sigdelset(&critical_prot, SIGSEGV);
        sigdelset(&critical_prot, SIGILL);
        sigdelset(&critical_prot, SIGBUS);
        sigdelset(&critical_prot, SIGINT);
        sigdelset(&critical_prot, SIGABRT);
        sigdelset(&critical_prot, SIGFPE);
    }
    #endif

    pthread_sigmask(SIG_BLOCK, &critical_prot, &old_sig);
    if(need_lock) {
        if(BOX64ENV(dynarec_wait)) {
            mutex_lock(&my_context->mutex_dyndump);
        } else {
            if(mutex_trylock(&my_context->mutex_dyndump)) {   // FillBlock not available for now
                pthread_sigmask(SIG_SETMASK, &old_sig, NULL);
                return NULL;
            }
        }
        block = getDB(addr);    // just in case
        if(block && block->to_delete) {
            // just delete the block then, so we can create a new one right away
            FreeDynablock(block, 0, 1);
            block = NULL;
        }
        if(block) {
            if(block && getNeedTest(addr) && (getProtection_fast(block->x64_readaddr)&req_prot)!=req_prot)
                block = NULL;
            mutex_unlock(&my_context->mutex_dyndump);
            pthread_sigmask(SIG_SETMASK, &old_sig, NULL);
            return block;
        }
    }
    #ifdef BOX64EC
    // a fault while filling the block would leave mutex_dyndump locked, the interpreter raises it instead
    block = Box64EC_IsExecutable(addr) ? FillBlock64(addr, is32bits, MAX_INSTS, is_new, 0) : NULL;
    #else
    block = FillBlock64(addr, is32bits, MAX_INSTS, is_new, 0);
    #endif
    if(!block) {
        dynarec_log(LOG_DEBUG, "Fillblock of block %p for %p returned an error\n", block, (void*)addr);
    }
    // check size
    if(block) {
        // fill-in jumptable
        if(!addJumpTableIfDefault64((void*)addr, (block->dirty || block->always_test)?block->jmpnext:block->block)) {
            FreeDynablock(block, 0, 0);
            block = getDB(addr);
            MarkDynablock(block);   // just in case...
        } else {
            if(block->dirty)
                block->dirty = 0;
            if(block->x64_size) {
                if(block->x64_size>my_context->max_db_size) {
                    my_context->max_db_size = block->x64_size;
                    dynarec_log(LOG_INFO, "BOX64 Dynarec: higher max_db=%d\n", my_context->max_db_size);
                }
                block->done = 1;    // don't validate the block if the size is null, but keep the block
                rb_inc(my_context->db_sizes, block->x64_size, block->x64_size+1);
            }
        }
    }
    if(need_lock)
        mutex_unlock(&my_context->mutex_dyndump);
    pthread_sigmask(SIG_SETMASK, &old_sig, NULL);

    dynarec_log(LOG_DEBUG, "%04d| --- DynaRec Block %p created @%p:%p (%p, 0x%x bytes)\n", GetTID(), block, (void*)addr, (void*)(addr+((block)?block->x64_size:1)-1), (block)?block->block:0, (block)?block->size:0);

    return block;
}

void FlushZombieDynablocks(void)
{
    if (!my_context) return;
    if (my_context->db_orphan_count) {
        for (int i = 0; i < my_context->db_orphan_count; ++i)
            if (my_context->db_orphan[i] && native_lock_get_d(&my_context->db_orphan[i]->in_used) <= 0)
                FreeDynarecMap((uintptr_t)my_context->db_orphan[i]->actual_block);
        box_free(my_context->db_orphan);
        my_context->db_orphan = NULL;
        my_context->db_orphan_size = 0;
        my_context->db_orphan_count = 0;
    }
    if (!my_context->db_zombie_count) return;
    int head = my_context->db_zombie_head;
    for (int i = 0; i < my_context->db_zombie_count; ++i) {
        int idx = (head - my_context->db_zombie_count + i + DB_ZOMBIE_SIZE) % DB_ZOMBIE_SIZE;
        if (my_context->db_zombie[idx] && native_lock_get_d(&my_context->db_zombie[idx]->in_used) <= 0)
            FreeDynarecMap((uintptr_t)my_context->db_zombie[idx]->actual_block);
    }
    my_context->db_zombie_count = 0;
}

dynablock_t* DBGetBlock(x64emu_t* emu, uintptr_t addr, int create, int is32bits)
{
    int is_inhotpage = isInHotPage(addr);
    dynablock_t* db = NULL;
    if(!is_inhotpage && !BOX64ENV(dynarec_dirty)) {
        db = getDB(addr);
        if(db && db->x64_size) {
            uintptr_t dbstart = (uintptr_t)db->x64_addr;
            uintptr_t dbend = dbstart + db->x64_size;
            for(uintptr_t page = (dbstart&~(X86_PAGE_SIZE-1)); page < dbend; page += X86_PAGE_SIZE) {
                if(page == (addr&~(X86_PAGE_SIZE-1))) continue; // skip the first page
                if(checkInHotPage(page)) {
                    is_inhotpage = 1;
                    break;
                }
            }
        }
        if(!db)
            db = SEARCHED_NO_DYNABLOCK;
    }
    if(is_inhotpage && !BOX64ENV(dynarec_dirty))
        return NULL;
    db = internalDBGetBlock(emu, addr, create, 1, is32bits, 1, db);
    if(db && db->done && db->block && getNeedTest(addr)) {
        //if (db->always_test) SchedYield(); // just calm down...
        #ifdef BOX64EC
        // protect the code before hashing it: a write that lands after the hash then faults and bumps the generation
        uint32_t gen = getUnprotectGeneration();
        if(!is_inhotpage && !db->always_test)
            protectDB((uintptr_t)db->x64_addr, db->x64_size);
        #endif
        uint32_t hash = X31_hash_code((void*)db->x64_readaddr, db->x64_size);
        mutex_lock(&my_context->mutex_dyndump)?1:0;
        if(hash!=db->hash) {
            if (is_inhotpage) {
                mutex_unlock(&my_context->mutex_dyndump);
                dynarec_log(LOG_DEBUG, "Cannot run block %p from %p:%p (hash:%X/%X, always_test:%d) for %p, hotpage\n", db, db->x64_addr, db->x64_addr + db->x64_size - 1, hash, db->hash, db->always_test, (void*)addr);
                return NULL; // will be handled when hotpage is over
            }
            db->done = 0;
            dynarec_log(LOG_DEBUG, "Invalidating block %p from %p:%p (hash:%X, gone:%d, autocrc:%d, to_delete:%d) for %p\n", db, db->x64_addr, db->x64_addr + db->x64_size, db->hash, db->gone, db->autocrc, db->to_delete, (void*)addr);
            dynablock_t* old = InvalidDynablock(db, 0);
            FreeInvalidDynablock(old, 0);
            db = internalDBGetBlock(emu, addr, 1, 0, is32bits, 0, SEARCHED_NO_DYNABLOCK);
        } else {
            if(is_inhotpage) {
                db->always_test = 2;
                // log?
            } else {
                dynarec_log(LOG_DEBUG, "Validating block %p from %p:%p (hash:%X, always_test:%d) for %p\n", db, db->x64_addr, db->x64_addr+db->x64_size-1, db->hash, db->always_test, (void*)addr);
                if(db->always_test) {
                    if(db->always_test==2) {
                        db->always_test = 0;
                        protectDB((uintptr_t)db->x64_addr, db->x64_size);
                    }
                    // always_test==1 (NEVERCLEAN): skip protectDB, the page has mixed
                    // code+data and mprotect would strip writability from data regions
                } else {
                    #ifdef ARCH_NOP
                    if(db->callret_size) {
                        // mark all callrets to UDF
                        for(int i=0; i<db->callret_size; ++i)
                            *(uint32_t*)(db->block+db->callrets[i].offs) = ARCH_NOP;
                        ClearCache(db->block, db->size);
                    }
                    #endif
                    #ifdef BOX64EC
                    if(gen == getUnprotectGeneration()) {   // else it stays tested at each entry
                    #endif
                    protectDBJumpTable((uintptr_t)db->x64_addr, db->x64_size, db->block, db->jmpnext);
                    #ifdef BOX64EC
                        // a write fault right before the publication may have unlinked it already
                        if(gen != getUnprotectGeneration())
                            MarkDynablock(db);
                    }
                    #endif
                }
            }
        }
        mutex_unlock(&my_context->mutex_dyndump);
    } 
    if(!db || !db->block || !db->done)
        emu->test.test = 0;
    return db;
}

uintptr_t getX64Address(dynablock_t* db, uintptr_t native_addr)
{
    if ((native_addr < (uintptr_t)db->block) || (native_addr > (uintptr_t)db->actual_block + db->size))
        return 0;
    uintptr_t x64addr = (uintptr_t)db->x64_addr;
    uintptr_t armaddr = (uintptr_t)db->block;
    if (!db->isize) return x64addr;
    if(native_addr<(uintptr_t)db->block+db->prefixsize)
        // issue indide the prefix, return as the 1st opcode
        return x64addr;
    armaddr += db->prefixsize;
    int i = 0;
    do {
        int x64sz = 0;
        int armsz = 0;
        do {
            x64sz += db->instsize[i].x64;
            armsz += db->instsize[i].nat * 4;
            ++i;
        } while ((db->instsize[i - 1].x64 == 15) || (db->instsize[i - 1].nat == 15));
        // if the opcode is a NOP on ARM side (so armsz==0), it cannot be an address to find
        if ((native_addr >= armaddr) && (native_addr < (armaddr + armsz)))
            return x64addr;
        armaddr += armsz;
        x64addr += x64sz;
    } while (db->instsize[i].x64 || db->instsize[i].nat);
    return x64addr;
}

int getX64AddressInst(dynablock_t* db, uintptr_t x64pc)
{
    uintptr_t x64addr = (uintptr_t)db->x64_addr;
    uintptr_t armaddr = (uintptr_t)db->block;
    int ret = 0;
    if (x64pc < (uintptr_t)db->x64_addr || x64pc > (uintptr_t)db->x64_addr + db->x64_size)
        return -1;
    armaddr += db->prefixsize;
    int i = 0;
    do {
        int x64sz = 0;
        int armsz = 0;
        do {
            x64sz += db->instsize[i].x64;
            armsz += db->instsize[i].nat * 4;
            ++i;
        } while ((db->instsize[i - 1].x64 == 15) || (db->instsize[i - 1].nat == 15));
        // if the opcode is a NOP on ARM side (so armsz==0), it cannot be an address to find
        if ((x64pc >= x64addr) && (x64pc < (x64addr + x64sz)))
            return ret;
        armaddr += armsz;
        x64addr += x64sz;
        ret++;
    } while (db->instsize[i].x64 || db->instsize[i].nat);
    return ret;
}

uintptr_t getX64InstAddress(dynablock_t* db, int inst)
{
    uintptr_t x64addr = (uintptr_t)db->x64_addr;
    uintptr_t armaddr = (uintptr_t)db->block + db->prefixsize;
    if (inst < 0 || inst > db->isize)
        return (uintptr_t)-1LL;
    int i = 0;
    int ret = 0;
    do {
        if (inst == ret)
            return x64addr;
        int x64sz = 0;
        int armsz = 0;
        do {
            x64sz += db->instsize[i].x64;
            armsz += db->instsize[i].nat * 4;
            ++i;
        } while ((db->instsize[i - 1].x64 == 15) || (db->instsize[i - 1].nat == 15));
        // if the opcode is a NOP on ARM side (so armsz==0), it cannot be an address to find
        armaddr += armsz;
        x64addr += x64sz;
        ret++;
    } while (db->instsize[i].x64 || db->instsize[i].nat);
    return (uintptr_t)-1LL;
}
