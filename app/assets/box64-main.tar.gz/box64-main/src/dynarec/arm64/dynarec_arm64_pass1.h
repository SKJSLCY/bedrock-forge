// SPDX-License-Identifier: MIT
#define INIT    
#define FINI
#define MESSAGE(A, ...) do {} while (0)
#define EMIT(A) do {} while (0)
#define LEMIT(A)        do {dyn->insts[ninst].has_lrcpc = 1; EMIT(A);} while(0)

// do not update dyn->f for SETFLAGS(..., SF_SET_PENDING) because it will use either DF_NONE or DF_SET anyway (similar to SF_SET_NODF)
#define SETFLAGS(A,B)                                                   \
    do {                                                                \
        dyn->insts[ninst].x64.set_flags = A;                            \
        dyn->insts[ninst].x64.state_flags = (B)&~SF_DF;                 \
        if(((B)&SF_SET_PENDING)!=SF_SET_PENDING) dyn->f=((B)&SF_SET)?(((B)==SF_SET_NODF)?dyn->f:status_none_pending):((dyn->f==status_none)?status_none:status_none_pending);  \
        if(!BOX64ENV(dynarec_df)) {dyn->f = status_none; }              \
    } while(0)
#define NEW_INST                                \
        dyn->insts[ninst].f_entry = dyn->f;     \
        dyn->n.combined1 = dyn->n.combined2 = 0;\
        dyn->n.swapped = 0; dyn->n.barrier = 0; \
        AREFLAGSNEEDED()

#define INST_EPILOG                             \
        dyn->insts[ninst].n = dyn->n;           \
        dyn->insts[ninst].f_exit = dyn->f;      \
        if(dyn->insts[ninst].use_lrcpc && (!dyn->insts[ninst].has_lrcpc || is_addr_lrcpc(ip))) \
            dyn->insts[ninst].use_lrcpc = 0

#define INST_NAME(name)

#define NATIVE_RESTORE_X87PC()
#define X87_CHECK_PRECISION(A)                  \
    do {                                        \
        if (dyn->need_x87check) {               \
            dyn->insts[ninst].x87precision = 1; \
            if (!ST_IS_F(0))                    \
                dyn->need_x87check = 2;         \
        }                                       \
    } while (0)
