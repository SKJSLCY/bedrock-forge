// SPDX-License-Identifier: MIT
#ifndef __BOX64_VERSION_H_
#define __BOX64_VERSION_H_

#define BOX64_MAJOR 0
#define BOX64_MINOR 4
#define BOX64_REVISION 5

#endif //__BOX64_VERSION_H_
